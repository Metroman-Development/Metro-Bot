
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const { deepSearch } = require('./searchUtils');

const { normalize } = require('./stringUtils');

const styles = require('../config/styles.json');

const metroConfig = require('../config/metroConfig');

const stationsData = require('../data/stationsData.json');

const { getCachedMetroData } = require('../events/metroDataHandler');

// Import the renamed embed functions

const { generalStationInfo } = require('../config/defaultEmbeds/generalStationInfo');

const { stationSurroundings } = require('../config/defaultEmbeds/stationSurroundings');

// 🚇 Function to get station details from metroData and stationsData using deepSearch


async function getStationData(stationName, interaction = null) {
    if (!stationName) {
        console.error('❌ stationName is undefined or null.');
        return null;
    }

    console.log(`Fetching data for station: ${stationName}`);

    // Use deepSearch to find the metro station
    const matches = await deepSearch(stationName, { needsOneMatch: true, interaction });

    if (!matches || matches.length === 0) {
        console.error(`❌ No matches found for station: ${stationName}`);
        return null;
    }

    const selectedMatch = matches; // If disambiguation was triggered, matches is the selected station
    console.log(`Selected station for data retrieval: ${selectedMatch}`);

    const metroData = getCachedMetroData();
    if (!metroData) {
        console.error('❌ metroData is undefined or could not be loaded.');
        return null;
    }

    console.log(selectedMatch);

    // Parse the selectedMatch string to extract the station name and line (if present)
    const [stationNameParsed, lineSuffix] = selectedMatch.split(' ');
    const line = lineSuffix ? lineSuffix.replace('l', '') : null; // Remove 'l' from the line suffix (e.g., "L6" -> "6")

    // Normalize the station name for comparison
    const normalizedStationName = normalize(stationNameParsed.toLowerCase());
    console.log(`Normalized station name: ${normalizedStationName}`);

    // Ensure the line number is prefixed with 'l'
    const lineKey = line ? `l${line}` : null;

    // Find the station in metroData
    let metroStation;
    if (lineKey) {
        // If a line is provided, search for the station in the specific line
        metroStation = metroData[lineKey]?.estaciones
            .find(estacion => normalize(estacion.nombre.toLowerCase()) === normalizedStationName);
    } else {
        // If no line is provided, search for the station across all lines
        metroStation = Object.values(metroData).flatMap(line => line.estaciones)
            .find(estacion => normalize(estacion.nombre.toLowerCase()) === normalizedStationName);
    }

    if (!metroStation) {
        console.error(`❌ No metro station found for: ${normalizedStationName}`);
        return null;
    }

    console.log(`Metro station found: ${metroStation.nombre}`);

    // Access static station data using the normalized station name
    const staticStationData = stationsData.stationsData[normalizedStationName] || [];
    if (!staticStationData.length) {
        console.error(`❌ No static data found for station: ${normalizedStationName}`);
        return null;
    }

    console.log(`Static station data: ${JSON.stringify(staticStationData)}`);
    const staticSchemsLink = stationsData.stationsSchematics[normalizedStationName][0]|| 'No disponible';

    console.log(`Station data retrieved successfully: ${metroStation.nombre}`);

    return {
        nombre: metroStation.nombre,
        line: lineKey || 'No disponible',
        combinacion: metroStation.combinacion || null,
        status: {
            code: metroStation.estado || 'No disponible',
            description: metroStation.descripcion_app || '🔴 No disponible',
        },
        details: {
            servicios: staticStationData[1] || '❌ No disponible',
            accesibilidad: staticStationData[2] || '❌ No disponible',
            cultura: staticStationData[4] || '❌ No disponible',
            comuna: staticStationData[6] || '❌ No disponible',
        },
        schematic: staticSchemsLink || null,
        mapLink: staticStationData[5],
    };
}


// 🏗️ Function to create the General Info Menu

function createGeneralInfoEmbed(station) {

    // Simply call the embed function and pass the station object

    return generalStationInfo(station);

}

// 🗺️ Function to create the Surroundings Info Menu

function createSurroundingsEmbed(station) {

    // Simply call the embed function and pass the station object

    return stationSurroundings(station);

} 


// ✅ Export all functions

module.exports = {

    getStationData,

    createGeneralInfoEmbed,

    createSurroundingsEmbed,
    
    

};




