const { normalize } = require('./stringUtils');

const stationsData = require('../data/stationsData.json');

const { getCachedMetroData } = require('../events/metroDataHandler');

const getStationData = (query, parameters = [], lineFilter = null) => {

    // Validate query parameter

    if (typeof query !== 'string' || query.trim() === '') {

        console.error('Invalid station query:', query);

        return null;

    }

    const normalizedQuery = normalize(query.toLowerCase());

    const metroData = getCachedMetroData();

    if (!metroData || typeof metroData !== 'object') {

        console.error('No valid metro data available.');

        return null;

    }

    // Station search logic

    const matches = [];

    for (const [lineKey, line] of Object.entries(metroData)) {

        // Skip lines that don't match the filter

        if (lineFilter && lineKey.toLowerCase() !== lineFilter.toLowerCase()) {

            continue;

        }

        if (line.estaciones?.length) {

            for (const estacion of line.estaciones) {

                const normalizedName = normalize(estacion.nombre.toLowerCase());

                if (normalizedName === normalizedQuery) {

                    matches.push({

                        ...estacion,

                        line: lineKey

                    });

                }

            }

        }

    }

    // Handle station combinations (e.g., Ñuñoa)

    if (matches.length > 1 && !lineFilter) {

        console.log(`Multiple matches found for station: ${query}`);

        return {

            isCombination: true,

            matches: matches.map(match => ({

                name: match.nombre,

                line: match.line

            }))

        };

    }

    // If no matches found

    if (matches.length === 0) {

        console.log(`No station found for query: ${query}`);

        return null;

    }

    // Use the first match if no line filter is provided

    const stationInfo = matches[0];

    // Static data references

    const staticStationData = stationsData.stationsData[stationInfo.nombre.toLowerCase()];

    const staticSchematicData = stationsData.stationsSchematics[stationInfo.nombre.toLowerCase()];

    // Build result object

    const result = {};

    parameters.forEach(param => {

        switch (param) {

            case 'name':

                result.name = stationInfo.nombre;

                break;

            case 'código':  // New case for station code

                result.código = stationInfo.codigo;

                break;

            case 'status':

                result.status = {

                    code: stationInfo.estado,

                    description: stationInfo.descripcion_app,

                    message: stationInfo.mensaje

                };

                break;

            case 'details':

                result.details = {

                    servicios: staticStationData?.[1] || 'No disponible',

                    accesibilidad: staticStationData?.[2] || 'No disponible',

                    cultura: staticStationData?.[4] || 'No disponible',

                    comuna: staticStationData?.[6] || 'No disponible'

                };

                break;

            case 'line':

                result.line = stationInfo.line || 'unknown';

                break;

            case 'schematic':

                result.schematic = staticSchematicData || [];

                break;

            default:

                console.warn(`Unknown parameter: ${param}`);

        }

    });

    return result;

};

module.exports = { getStationData };