 const { performance } = require('perf_hooks');
const { normalize: sharedNormalize } = require('./stringUtils');
const stringSimilarity = require('string-similarity');
const metaphone = require('./metaphone');
const logger = require('../events/logger');
const { createDisambiguationEmbed } = require('../config/defaultEmbeds/disambiguationEmbed');
const { loadStationData, getAllStations } = require('./dataUtils');
const { setCache } = require('./cache');

// Optimized similarity search with phonetic matching
function findSimilarMatches(query, threshold = 0.75) {
    const normalizedQuery = sharedNormalize(query);
    const queryPhonetic = metaphone(normalizedQuery); // Generate phonetic code for query
    const allStations = Object.values(getAllStations()); // Get all stations from dataUtils

    return allStations
        .map(station => {
            const normalizedStation = station.normalized || '';
            const phoneticStation = station.phonetic || '';

            const normalizedScore = normalizedQuery && normalizedStation
                ? stringSimilarity.compareTwoStrings(normalizedQuery, normalizedStation)
                : 0;

            const phoneticScore = queryPhonetic && phoneticStation
                ? stringSimilarity.compareTwoStrings(queryPhonetic, phoneticStation)
                : 0;

            return {
                ...station,
                score: Math.max(normalizedScore, phoneticScore) // Use the best score
            };
        })
        .filter(match => match.score >= threshold)
        .sort((a, b) => b.score - a.score);
}

// Enhanced deep search with multiple matching strategies
async function deepSearch(stationQuery, options = {}) {
    const startTime = performance.now();
    const { maxResults = 5, needsOneMatch = false, interaction = null } = options;

    if (!loadStationData()) {
        logger.error('Failed to load station data');
        return [];
    }

    // Parse line suffix (e.g., "San Pablo L1")
    const lineSuffixRegex = /^(.+?)(?:\s+(?:L|linea)[\s-]*(\d+[a-zA-Z]*))?$/i;
    const lineMatch = stationQuery.match(lineSuffixRegex);
    let query = stationQuery;
    let lineFilter = null;

    if (lineMatch && lineMatch[2]) {
        query = lineMatch[1].trim();
        lineFilter = lineMatch[2].toLowerCase();
        logger.debug(`Parsed line suffix. Query: "${query}", Line Filter: "${lineFilter}"`);
    }

    // Combine exact, partial, and phonetic matches
    const matches = [
        ...findExactMatches(query),
        ...findPartialMatches(query),
        ...findSimilarMatches(query, 0.65) // Lower threshold for phonetic matches
    ].filter(match => !lineFilter || match.line === lineFilter); // Apply line filter

    // Deduplicate and prioritize matches
    const uniqueMatches = Array.from(new Map(
        matches.map(match => [match.original, match])
    ).values());

    logger.debug(`deepSearch "${stationQuery}" took ${(performance.now() - startTime).toFixed(2)}ms`);

    // Handle needsOneMatch logic
    if (needsOneMatch) {
        if (uniqueMatches.length === 0) {
            logger.warn(`No matches found for query: ${query}`);
            return null;
        }

        // Check for single 100% partial match
        const perfectMatches = uniqueMatches.filter(m => m.score === 1);
        if (perfectMatches.length === 1) {
            return perfectMatches[0]; // Return the single perfect match
        }

        // Check if multiple matches remain after filtering
        if (uniqueMatches.length > 1) {
            // Trigger disambiguation ONLY if:
            // - No exact match
            // - No single perfect partial match
            // - Needs one match
            if (interaction) {
                return new Promise((resolve) => {
                    const userId = interaction.user.id;
                    const embedId = `${userId}_${interaction.id}`;
                    setCache(userId, embedId, {
                        data: uniqueMatches,
                        resolve,
                        originalQuery: query,
                        lineFilter
                    });

                    const { embed, actionRows } = createDisambiguationEmbed(query, uniqueMatches, interaction);
                    
                    console.log("OOIIA: ", actionRows) ;
                    interaction.editReply({ embeds: [embed], components: actionRows });
                    logger.debug(`Disambiguation embed sent for query: "${query}"`);
                });
            }
        }
        
        console.log(uniqueMatches) ;

        // Return the top match if not triggering disambiguation
        return uniqueMatches[0];
    }

    return uniqueMatches.slice(0, maxResults).map(m => m.original);
}

// Exact match using preprocessed data
function findExactMatches(query) {
    const allStations = Object.values(getAllStations());
    const normalizedQuery = sharedNormalize(query);
    const exactMatch = allStations.find(station => station.normalized === normalizedQuery);
    return exactMatch ? [exactMatch] : [];
}

// Partial match with word boundary check
function findPartialMatches(query) {
    const normalizedQuery = sharedNormalize(query);
    const allStations = Object.values(getAllStations());
    return allStations.filter(station =>
        station.normalized.includes(normalizedQuery) ||
        normalizedQuery.includes(station.normalized)
    );
}

module.exports = {
    deepSearch
};

