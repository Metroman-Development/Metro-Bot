const { createEmbed } = require('../utils/embeds');
const logger = require('../events/logger'); // Import logger

const ERROR_CHANNEL_ID = '1350243847271092295'; // Channel ID for error summaries

// Function to send error embed to the specified channel
async function sendErrorEmbed(client, error) {
    try {
        const errorChannel = await client.channels.fetch(ERROR_CHANNEL_ID);
        if (!errorChannel) {
            logger.error('Error channel not found. Please check the channel ID.');
            return;
        }

        // Create an embed for the error
        const embed = createEmbed(
            `**Error Message:** ${error.message}\n\n**Stack Trace:**\n\`\`\`${error.stack}\`\`\``,
            'error',
            '🚨 Error Detected'
        );

        // Send the embed to the error channel
        await errorChannel.send({ embeds: [embed] });
        logger.info('Error embed sent to the error channel.');
    } catch (error) {
        logger.error(`Failed to send error embed: ${error.message}`);
    }
}

// Function to initialize global error handlers
function initializeErrorDetector(client) {
    logger.info('Initializing error detector...');

    // Listen for unhandled promise rejections
    process.on('unhandledRejection', (error) => {
        logger.error('Unhandled Rejection:', error);
        sendErrorEmbed(client, error); // Send error embed
    });

    // Listen for uncaught exceptions
    process.on('uncaughtException', (error) => {
        logger.error('Uncaught Exception:', error);
        sendErrorEmbed(client, error); // Send error embed
        process.exit(1); // Exit the process after handling the error
    });

    // Listen for Discord API errors
    client.on('error', (error) => {
        logger.error('Discord API Error:', error);
        sendErrorEmbed(client, error); // Send error embed
    });

    logger.info('Error detector initialized.');
}

module.exports = { initializeErrorDetector };