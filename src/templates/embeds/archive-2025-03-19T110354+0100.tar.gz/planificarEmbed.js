const { EmbedBuilder } = require('discord.js');
const styles = require('../styles.json');
const { normalize } = require('../../utils/stringUtils');
const { getCachedMetroData } = require('../../events/metroDataHandler');
const metroConfig = require('../metroConfig');

// --------------------------
// Helper Functions
// --------------------------

/**
 * Format the line name with its corresponding emoji.
 * @param {string} line - The line identifier (e.g., "l1", "l5").
 * @returns {string} The formatted line name with emoji.
 */
function formatLineName(line) {
    if (!line) return '🚇 Línea Desconocida'; // Default if line is missing
    const lineEmojis = metroConfig.linesEmojis;
    return `${lineEmojis[line] || '🚇'} Línea ${line.replace('l', '')}`;
}

/**
 * Get the emoji for a specific route type.
 * @param {string} routeType - The route type (e.g., "Ruta Verde", "Ruta Roja").
 * @returns {string} The emoji for the route or an empty string if not found.
 */
function getRouteEmoji(routeType) {
    if (!routeType) return ''; // Default if routeType is missing
    const normalizedType = normalize(routeType?.replace("Ruta ", "") || '');
    return metroConfig.stationIcons[normalizedType]?.emoji || '';
}

// --------------------------
// Status Handling Utilities
// --------------------------

const statusMessages = {
    2: { emoji: '⛔', text: 'Estación completamente cerrada' },
    3: { emoji: '🚧', text: 'Solo transferencias permitidas' },
    4: { emoji: '⚠️', text: 'Retrasos en la línea' }
};

/**
 * Get the status of a station from cached data.
 * @param {string} stationName - The name of the station.
 * @returns {number} The status code (0 = normal, 2 = closed, 3 = transfer only, 4 = delays).
 */
function getStationStatus(stationName) {
    if (!stationName) return 0; // Default to normal if station name is missing
    const metroData = getCachedMetroData();
    for (const line of Object.values(metroData)) {
        const station = line.estaciones.find(s => s.nombre === stationName);
        if (station) return station.estado || 0; // Default to normal if status is missing
    }
    return 0; // Default to normal if station not found
}

/**
 * Get the status of a line from cached data.
 * @param {string} line - The line identifier (e.g., "l1", "l5").
 * @returns {number} The status code (0 = normal, 4 = delays).
 */
function getLineStatus(line) {
    if (!line) return 0; // Default to normal if line is missing
    const metroData = getCachedMetroData();
    return metroData[line]?.estado || 0; // Default to normal if status is missing
}

// --------------------------
// Enhanced Station Counting
// --------------------------

/**
 * Count the number of stations between two stations, categorizing them by route type.
 * @param {string} startStationName - The name of the starting station.
 * @param {string} endStationName - The name of the ending station.
 * @param {string} farePeriod - The fare period (e.g., "PUNTA").
 * @returns {Object} An object with counts for "verde", "roja", and "total" stations.
 */
function countStationsBetween(startStationName, endStationName, farePeriod) {
    if (!startStationName || !endStationName) return { verde: 0, roja: 0, total: 0 }; // Default if stations are missing
    const metroData = getCachedMetroData();
    const allStations = Object.values(metroData).flatMap(line => line.estaciones);
    const startStation = allStations.find(s => s.nombre === startStationName);
    const endStation = allStations.find(s => s.nombre === endStationName);

    if (!startStation || !endStation) return { verde: 0, roja: 0, total: 0 }; // Default if stations not found

    const startIndex = allStations.findIndex(s => s === startStation);
    const endIndex = allStations.findIndex(s => s === endStation);
    const direction = startIndex < endIndex ? 1 : -1;

    let verde = 0;
    let roja = 0;
    let total = 0;

    for (let i = startIndex + direction; i !== endIndex; i += direction) {
        const current = allStations[i];
        if (!current) continue; // Skip if station is missing
        total++;

        if (current.route === 'Común') {
            verde++;
            roja++;
        } else if (current.route === 'Ruta Verde') {
            verde++;
        } else if (current.route === 'Ruta Roja') {
            roja++;
        }
    }

    return { verde, roja, total };
}

/**
 * Helper function to pluralize "estación" correctly.
 * @param {number} count - The number of stations.
 * @returns {string} "estación" or "estaciones".
 */
function pluralizeEstacion(count) {
    return count === 1 ? 'estación' : 'estaciones';
}

// --------------------------
// Route Embed with Status Handling
// --------------------------

/**
 * Create a Discord embed for a specific route with status awareness.
 * @param {Object} route - The route object containing tramos, tiempo, and cambios.
 * @param {Object} startDetails - The starting station details (name, linea).
 * @param {Object} endDetails - The ending station details (name, linea).
 * @param {string} farePeriod - The fare period (e.g., "PUNTA").
 * @returns {EmbedBuilder} The Discord embed for the route.
 */
function createRouteEmbed(route, startDetails, endDetails, farePeriod) {
    const warnings = new Set();
    let isRouteBlocked = false;

    // Obtener estaciones inicial/final
    const firstTramo = route.tramos[0];
    const lastTramo = route.tramos[route.tramos.length - 1];
    const startStation = firstTramo?.inicio?.nombre || startDetails?.nombre || 'Desconocido';
    const endStation = lastTramo?.fin?.nombre || endDetails?.nombre || 'Desconocido';

    const tramos = route.tramos.flatMap((tramo, index) => {
        
        console.log(tramo) ;
        
        if (isRouteBlocked) return [];
        if (!tramo?.tipo) return [];

        // ======================
        // Manejo de Transferencias
        // ======================
        if (tramo.tipo === 'combinacion' || tramo.tipo === 'cambio') {
            const prevTramo = route.tramos[index - 1];
            const nextTramo = route.tramos[index + 1];
            
            const fromStation = prevTramo?.fin?.nombre || startStation;
            const toLine = formatLineName(nextTramo?.inicio?.linea || tramo.linea);
            
            return `🔀 **Combina en ${fromStation}**\n└→ ${toLine} (${tramo.direccion || 'sin dirección'})`;
        }

        // ======================
        // Manejo de Tramo Regular
        // ======================
        if (tramo.tipo === 'tramo') {
            if (!tramo.inicio || !tramo.fin) return [];

            // Verificar estado
            const currentStatus = getStationStatus(tramo.inicio.nombre);
            const nextStatus = getStationStatus(tramo.fin.nombre);
            if ([currentStatus, nextStatus].includes(2)) {
                isRouteBlocked = true;
                warnings.add(`${statusMessages[2].emoji} Ruta bloqueada: ${tramo.inicio.nombre} → ${tramo.fin.nombre}`);
                return [];
            }

            // Generar mensaje estilo específico
            const counts = countStationsBetween(tramo.inicio.nombre, tramo.fin.nombre, farePeriod);
            const lineEmoji = formatLineName(tramo.fin.linea);
            
            return `🚉 **Viaja ${getRouteEmoji('Verde')} ${counts.verde} ${pluralizeEstacion(counts.verde)} ` +
                   `o ${getRouteEmoji('Roja')} ${counts.roja} ${pluralizeEstacion(counts.roja)} hasta ` +
                   `${lineEmoji} ${tramo.fin.nombre}**`;
        }

        return [];
    });

    // Construir Embed
    return new EmbedBuilder()
        .setTitle(`${metroConfig.logoMetroEmoji} Planificador de Ruta`)
        .setColor(styles.defaultTheme.infoColor)
        .setDescription(
            `**Desde:** ${startStation}\n` +
            `**Hasta:** ${endStation}\n` +
            `**Horario:** ${farePeriod?.toUpperCase() || 'GENERAL'}`
        )
        .addFields(
            { name: '📋 Recorrido', value: tramos.join('\n') || 'No hay detalles' },
            ...(warnings.size > 0 ? [{
                name: '⚠️ Avisos',
                value: Array.from(warnings).join('\n')
            }] : [])
        );
}

// --------------------------
// Summary Embed with Status Awareness
// --------------------------

/**
 * Create a summary embed for multiple routes, filtering out blocked routes.
 * @param {Array} routes - The list of routes (fastest, balanced, slowest).
 * @param {Object} startDetails - The starting station details (name, linea).
 * @param {Object} endDetails - The ending station details (name, linea).
 * @param {string} farePeriod - The fare period (e.g., "PUNTA").
 * @returns {EmbedBuilder} The Discord embed for the route summary.
 */
function createSummaryEmbed(routes, startDetails, endDetails, farePeriod) {
    if (!Array.isArray(routes) || routes.length === 0) {
        return new EmbedBuilder()
            .setTitle('🚨 Error en el Resumen')
            .setDescription('No se encontraron rutas válidas.')
            .setColor(styles.defaultTheme.errorColor);
    }

    const statusFilteredRoutes = routes.filter(route => {
        return route.tramos.every(tramo => {
            if (!tramo || !tramo.inicio || !tramo.fin) {
                console.warn('Tramo inválido detectado:', tramo);
                return false; // Skip invalid tramos
            }

            const startStatus = getStationStatus(tramo.inicio.nombre);
            const endStatus = getStationStatus(tramo.fin.nombre);
            return startStatus !== 2 && endStatus !== 2; // Filter out blocked routes
        });
    });

    // If no valid routes are left after filtering, use the original routes
    const fastestRoute = statusFilteredRoutes[0] || routes[0];
    const balancedRoute = statusFilteredRoutes[1] || fastestRoute;
    const slowestRoute = statusFilteredRoutes[2] || fastestRoute;

    return new EmbedBuilder()
        .setTitle(`${metroConfig.logoMetroEmoji} Resumen de Rutas`)
        .setDescription(`**Desde:** ${startDetails.name || 'Desconocida'}\n**Hasta:** ${endDetails.name || 'Desconocida'}\n**Tarifa:** ${farePeriod}`)
        .addFields(
            { name: '🚀 Más Rápida', value: `${fastestRoute.tiempo || 'Desconocido'} min | ${fastestRoute.cambios || 'Desconocido'} cambios`, inline: true },
            { name: '⚖️ Balanceada', value: `${balancedRoute.tiempo || 'Desconocido'} min | ${balancedRoute.cambios || 'Desconocido'} cambios`, inline: true },
            { name: '🐢 Más Lenta', value: `${slowestRoute.tiempo || 'Desconocido'} min | ${slowestRoute.cambios || 'Desconocido'} cambios`, inline: true }
        )
        .setColor(styles.defaultTheme.infoColor);
}

module.exports = { createRouteEmbed, createSummaryEmbed };