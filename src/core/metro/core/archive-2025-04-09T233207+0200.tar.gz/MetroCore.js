// modules/metro/core/MetroCore.js
// modules/metro/core/MetroCore.js
// modules/metro/core/MetroCore.js
const EventEmitter = require('events');
const path = require('path');
const schedule = require('node-schedule');
const moment = require('moment-timezone');
const { performance } = require('perf_hooks');
const timeHelpers = require('../../chronos/timeHelpers');

// Core subsystems
const DataEngine = require('./internal/DataEngine');
const EventEngine = require('./internal/EventEngine');
const StatusEngine = require('./internal/StatusEngine');
const ScheduleEngine = require('./internal/ScheduleEngine');

// Original required modules
const DataLoader = require('./DataLoader');
const ApiService = require('./services/ApiService');
const EventRegistry = require('../../../core/EventRegistry');
const EventPayload = require('../../../core/EventPayload');
const stringUtils = require('../utils/stringHandlers');
const StatusProcessor = require('../../status/utils/StatusProcessor');
const ChangeAnnouncer = require('../../status/ChangeAnnouncer');
const logger = require('../../../events/logger');

class MetroCore extends EventEmitter {
    static #instance = null;
    static #initializationPromise = null;

    constructor(options = {}) {
        if (MetroCore.#instance) {
            return MetroCore.#instance;
        }

        super();
        MetroCore.#instance = this;

        if (!options.client) throw new Error("Client instance is required");
        
        this._debug = options.debug || false;
        this.client = options.client;
        this.config = require('../../../config/metro/metroConfig');
        this.styles = require('../../../config/metro/styles.json');
        
        // Initialize utils FIRST
        this._subsystems = {
            utils: {
                string: stringUtils,
                config: this.config,
                time: timeHelpers, 
                getSafe: (obj, path, def = null) => {
                    try {
                        return path.split('.').reduce((o, p) => o && o[p], obj) || def;
                    } catch (e) {
                        return def;
                    }
                }
            }
        };

        // Initialize managers with utils
        this._subsystems.managers = {
            stations: new (require('./managers/StationManager'))({}, this._subsystems.utils),
            lines: new (require('./managers/LineManager'))({}, this._subsystems.utils)
        };

        // Complete subsystems initialization
        this._subsystems = {
            ...this._subsystems,
            api: null, 
            dataLoader: new DataLoader(),
            scheduleHelpers: require('../../chronos/utils/scheduleHelpers'),
            changeDetector: null,
            statusProcessor: new StatusProcessor(this),
            statusService: null,
            statusUpdater: null,
            changeAnnouncer: new ChangeAnnouncer()
        };

        // Expose public API
        this.api = null;

        this._staticData = {};
        this._dynamicData = {};
        this._combinedData = {
            version: '0.0.0',
            lastUpdated: new Date(0),
            lines: {},
            stations: {},
            network: { status: 'initializing' }
        };
        this._dataVersion = '0.0.0';

        // Initialize engines
        this._engines = {
            data: new DataEngine(this),
            events: new EventEngine(this),
            status: new StatusEngine(this),
            schedule: new ScheduleEngine(this)
        };

        // Bind engine methods
        this._setupEventSystem = this._engines.events.setupSystem.bind(this._engines.events);
        this._safeEmit = this._engines.events.safeEmit.bind(this._engines.events);
        this._combineData = this._engines.data.combine.bind(this._engines.data);
        this._createStationInterface = this._engines.data.createStationInterface.bind(this._engines.data);
        this._createLineInterface = this._engines.data.createLineInterface.bind(this._engines.data);
        this._emitError = this._engines.events.emitError.bind(this._engines.events);
        this._initializeSchedulingSystem = this._engines.schedule.initialize.bind(this._engines.schedule);
        this._handleServiceTransition = this._engines.schedule.handleServiceTransition.bind(this._engines.schedule);
        this._handleExpressChange = this._engines.schedule.handleExpressChange.bind(this._engines.schedule);
        this._handleRawData = this._engines.data.handleRawData.bind(this._engines.data);
        this._enterSafeMode = this._engines.status.enterSafeMode.bind(this._engines.status);
        this._setupEventListeners = this._engines.events.setupListeners.bind(this._engines.events);
        this._removeAllListeners = this._engines.events.removeAllListeners.bind(this._engines.events);

        // Initialize
        this._setupEventSystem();
    }

    static async getInstance(options = {}) {
        if (this.#instance) return this.#instance;
        if (this.#initializationPromise) return this.#initializationPromise;

        this.#initializationPromise = (async () => {
            const instance = new MetroCore(options);
            await instance.initialize();
            return instance;
        })();

        return this.#initializationPromise;
    }

    async initialize() {
        try {
            logger.debug('[MetroCore] Starting phased initialization');

            // PHASE 1: Core Subsystems
            this._subsystems.changeDetector = new (require('./services/ChangeDetector'))(this);
            this._subsystems.statusService = new (require('../../status/StatusService'))(this);
            
            
            
            // Update ApiService initialization with processors
            this._subsystems.api = new ApiService({
                statusProcessor: this._subsystems.statusProcessor,
                changeDetector: this._subsystems.changeDetector,
                // ... other existing options if any ...
            });
            
            this.api = {
    changes: this._subsystems.api.api.changes,
    metrics: this._subsystems.api.api.metrics,
    getCacheState: this._subsystems.api.api.getCacheState,
    getProcessedData: this._subsystems.api.api.getProcessedData,
    status: this.getSystemStatus.bind(this)
};
            
            console.log(this._subsystems.api.api.getProcessedData) 
            
            

            
            // PHASE 2: Event System
            this._setupEventListeners();
            
            // PHASE 3: Data Loading
            this._staticData = await this._subsystems.dataLoader.load();
            this._dataVersion = this._staticData.version || `1.0.0-${Date.now()}`;
            
            // PHASE 4: Manager Initialization
            await this._subsystems.managers.stations.updateData(
                this._createStationInterface(this._staticData.stations || {})
            );
            await this._subsystems.managers.lines.updateData(
                this._createLineInterface(this._staticData.lines || {})
            );
            
            // PHASE 5: Scheduling
            await this._initializeSchedulingSystem();
            
            // PHASE 6: API Integration
            await this._subsystems.api.fetchNetworkStatus();
            this._subsystems.api.startPolling();
            
            // PHASE 7: Status System
            this._subsystems.statusUpdater = new (require('../../status/embeds/StatusUpdater'))(this, this._subsystems.changeDetector);
            await this._subsystems.statusUpdater.initialize();

            logger.debug('[MetroCore] Initialization complete');
            
            this._safeEmit(EventRegistry.SYSTEM_READY, { 
                version: '1.0.0',
                startupTime: Date.now()
            }, { source: 'MetroCore' });

        } catch (error) {
            console.error('[MetroCore] Initialization failed:', error);
            this._emitError('initialize', error);
            console.error(`MetroCore initialization failed: ${error.message}`);
        }
    }

    getSystemStatus() {
        return {
            version: this._dataVersion,
            status: this._combinedData.network,
            lastUpdated: this._combinedData.lastUpdated,
            lines: {
                total: Object.keys(this._combinedData.lines).length,
                operational: Object.values(this._combinedData.lines)
                    .filter(line => line.status.code === '1').length
            },
            stations: {
                total: Object.keys(this._combinedData.stations).length,
                operational: Object.values(this._combinedData.stations)
                    .filter(station => station.status.code === '1').length
            },
            changes: this.api.changes.history().stats
        };
    }

    startPolling(interval = 60000) {
        return this._subsystems.api.startPolling(interval);
    }

    stopPolling() {
        return this._subsystems.api.stopPolling();
    }

    sendFullStatusReport() {
        return this._engines.status.sendFullReport();
    }

    healthCheck() {
        return this._engines.status.healthCheck();
    }

    getStationManager() {
        return this._subsystems.managers.stations;
    }

    getLineManager() {
        return this._subsystems.managers.lines;
    }

    _enrichLines() {
        return this._engines.data.enrichLines();
    }

    _enrichStations() {
        return this._engines.data.enrichStations();
    }

    _updateListenerStats(event) {
        this._engines.events.updateListenerStats(event);
    }

    _checkBackpressure() {
        this._engines.events.checkBackpressure();
    }

    _calculateCurrentLoad() {
        return this._engines.schedule.calculateCurrentLoad();
    }

    _determineEmbedColor(status) {
        return this._engines.status.determineEmbedColor(status);
    }

    _generateLineStatusSummary(lines) {
        return this._engines.status.generateLineStatusSummary(lines);
    }
}

module.exports = MetroCore;