// PartialSearch.js 
const Metaphone = require('./utils/Metaphone');

module.exports = class PartialSearch {
  execute(query, { normalized, normalize }) {
    const queryNormalized = normalize(query);
    const { primary, alternate } = Metaphone.process(queryNormalized);

    return normalized.filter(item =>
      item.normalizedName.includes(queryNormalized) ||
      queryNormalized.includes(item.normalizedName) ||
      item.phonetic.primary.includes(primary) || 
      item.phonetic.alternate.includes(alternate)
    ).map(item => ({
      ...item,
      score: 0.8,
      matchType: 'partial'
    }));
  }
};