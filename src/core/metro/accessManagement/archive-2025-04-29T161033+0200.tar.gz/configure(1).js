const path = require('path');
const fs = require('fs').promises;
const { EmbedBuilder } = require('discord.js');
const AccessCore = require('./accessCore');
const BatchConfigure = require('./batchConfigure');

class ConfigureHandler extends AccessCore {
    constructor() {
        super();
        this.batch = new BatchConfigure();
        this.currentSection = 'all';
        this.currentPage = 0;
        this.message = null;
        this.currentConfig = null;
        this.stationKey = '';
        this.normalizedKey = '';
        this.activeCollector = null;
    }

    async handle(message, args) {
        try {
            if (args[0]?.toLowerCase() === 'aedit') {
                return this.batch.handleAdvancedEdit.call(this, message, args.slice(1));
            }
            
            if (args[0]?.toLowerCase() === 'replace') {
                return this.batch.handleReplaceOperation.call(this, message, args.slice(1));
            }

            const parsedArgs = this.parseQuotedArgs(args);
            const rawName = parsedArgs[0];
            const rawLine = parsedArgs[1];
            
            if (!rawName || !rawLine) {
                return this.sendError(message, 'Debes especificar nombre de estación y línea (ej: "San Pablo" l1)');
            }

            await this.ensureAccessDetailsDir();

            this.stationKey = `${rawName} ${rawLine}`;
            this.normalizedKey = this.normalizeKey(this.stationKey);
            this.currentConfig = await this.getAccessConfig(this.normalizedKey);

            if (!this.currentConfig) {
                this.currentConfig = this.createNewConfig(rawName, rawLine);
                await this.saveAccessConfig(this.normalizedKey, this.currentConfig);
                return this.promptForConfiguration(message, this.normalizedKey, this.currentConfig);
            }

            this.message = message;
            this.currentPage = 0;
            this.currentSection = 'all';

            const totalItems = this.currentConfig.accesses.length + 
                              this.currentConfig.elevators.length + 
                              this.currentConfig.escalators.length;

            if (totalItems <= 10) {
                return this.showFullConfiguration();
            }
            return this.showPaginatedConfiguration();
        } catch (error) {
            console.error('Configuration Error:', error);
            return this.sendError(message, `❌ Error: ${error.message}`);
        }
    }

    createNewConfig(stationName, line) {
        return {
            station: stationName,
            line: line,
            accesses: [],
            elevators: [],
            escalators: [],
            changeHistory: [],
            lastUpdated: new Date().toISOString()
        };
    }

    async showPaginatedConfiguration() {
        if (this.activeCollector) {
            this.activeCollector.stop();
            this.activeCollector = null;
        }

        const embed = this.createPaginatedEmbed();
        const sentMessage = await this.message.reply({ embeds: [embed] });

        try {
            await sentMessage.reactions.removeAll();
        } catch (error) {
            console.error('Failed to clear reactions:', error);
        }

        const reactionsToAdd = this.currentSection === 'all' 
            ? ['🚪', '🛗', '🔼', '❌'] 
            : [
                ...(this.hasPreviousPage() ? ['⬅️'] : []),
                ...(this.hasNextPage() ? ['➡️'] : []),
                '🏠', '❌'
            ];

        for (const reaction of reactionsToAdd) {
            try {
                await sentMessage.react(reaction);
                await new Promise(resolve => setTimeout(resolve, 500));
            } catch (error) {
                console.error(`Failed to add ${reaction}:`, error);
            }
        }

        const filter = (reaction, user) => {
            return !user.bot && 
                   user.id === this.message.author.id && 
                   ['🚪', '🛗', '🔼', '⬅️', '➡️', '🏠', '❌'].includes(reaction.emoji.name);
        };

        this.activeCollector = sentMessage.createReactionCollector({ 
            filter,
            time: 120000
        });

        this.activeCollector.on('collect', async (reaction, user) => {
            try {
                switch (reaction.emoji.name) {
                    case '🚪':
                        this.currentSection = 'accesses';
                        this.currentPage = 0;
                        break;
                    case '🛗':
                        this.currentSection = 'elevators';
                        this.currentPage = 0;
                        break;
                    case '🔼':
                        this.currentSection = 'escalators';
                        this.currentPage = 0;
                        break;
                    case '⬅️':
                        if (this.hasPreviousPage()) this.currentPage--;
                        break;
                    case '➡️':
                        if (this.hasNextPage()) this.currentPage++;
                        break;
                    case '🏠':
                        this.currentSection = 'all';
                        this.currentPage = 0;
                        break;
                    case '❌':
                        this.activeCollector.stop();
                        return;
                }

                const newEmbed = this.createPaginatedEmbed();
                await sentMessage.edit({ embeds: [newEmbed] });
                await reaction.users.remove(user.id);
            } catch (error) {
                console.error('Error handling reaction:', error);
            }
        });

        this.activeCollector.on('end', () => {
            sentMessage.reactions.removeAll().catch(() => {});
            this.activeCollector = null;
        });
    }

    hasPreviousPage() {
        return this.currentPage > 0;
    }

    hasNextPage() {
        switch (this.currentSection) {
            case 'accesses':
                return (this.currentPage + 1) * 7 < this.currentConfig.accesses.length;
            case 'elevators':
                return (this.currentPage + 1) * 7 < this.currentConfig.elevators.length;
            case 'escalators':
                return (this.currentPage + 1) * 7 < this.currentConfig.escalators.length;
            default:
                return false;
        }
    }

    getSectionName(section) {
        switch (section) {
            case 'accesses': return 'Accesos';
            case 'elevators': return 'Ascensores';
            case 'escalators': return 'Escaleras';
            default: return 'General';
        }
    }

    createPaginatedEmbed() {
        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle(`Configuración: ${this.stationKey}`)
            .setFooter({ 
                text: `Página ${this.currentPage + 1} | Sección: ${this.getSectionName(this.currentSection)}` 
            });

        switch (this.currentSection) {
            case 'accesses':
                embed.setDescription('**Accesos**');
                embed.addFields(this.getAccessesPage());
                break;
            case 'elevators':
                embed.setDescription('**Ascensores**');
                embed.addFields(this.getElevatorsPage());
                break;
            case 'escalators':
                embed.setDescription('**Escaleras**');
                embed.addFields(this.getEscalatorsPage());
                break;
            default:
                embed.setDescription('**Vista general**\nSelecciona una sección para ver detalles');
                embed.addFields(
                    { 
                        name: 'Accesos', 
                        value: `${this.currentConfig.accesses.length} registrados\n🚪 para ver`, 
                        inline: true 
                    },
                    { 
                        name: 'Ascensores', 
                        value: `${this.currentConfig.elevators.length} registrados\n🛗 para ver`, 
                        inline: true 
                    },
                    { 
                        name: 'Escaleras', 
                        value: `${this.currentConfig.escalators.length} registradas\n🔼 para ver`, 
                        inline: true 
                    }
                );
        }

        return embed;
    }

    getAccessesPage() {
        const startIdx = this.currentPage * 7;
        const pageItems = this.currentConfig.accesses.slice(startIdx, startIdx + 7);
        return {
            name: `Accesos (${startIdx + 1}-${startIdx + pageItems.length} de ${this.currentConfig.accesses.length})`,
            value: pageItems.map(a => `• ${a.name} (${a.id})`).join('\n') || 'No hay accesos',
            inline: false
        };
    }

    getElevatorsPage() {
        const startIdx = this.currentPage * 7;
        const pageItems = this.currentConfig.elevators.slice(startIdx, startIdx + 7);
        return {
            name: `Ascensores (${startIdx + 1}-${startIdx + pageItems.length} de ${this.currentConfig.elevators.length})`,
            value: pageItems.map(e => `• ${e.id}: ${e.from} → ${e.to}`).join('\n') || 'No hay ascensores',
            inline: false
        };
    }

    getEscalatorsPage() {
        const startIdx = this.currentPage * 7;
        const pageItems = this.currentConfig.escalators.slice(startIdx, startIdx + 7);
        return {
            name: `Escaleras (${startIdx + 1}-${startIdx + pageItems.length} de ${this.currentConfig.escalators.length})`,
            value: pageItems.map(e => `• ${e.id}: ${e.from} → ${e.to}`).join('\n') || 'No hay escaleras',
            inline: false
        };
    }

    async showFullConfiguration() {
        const embed = new EmbedBuilder()
            .setColor(0x0099FF)
            .setTitle(`Configuración actual: ${this.stationKey}`)
            .addFields(
                { 
                    name: 'Accesos', 
                    value: this.formatAccesses(this.currentConfig.accesses) || 'Ninguno', 
                    inline: true 
                },
                { 
                    name: 'Ascensores', 
                    value: this.formatElevators(this.currentConfig.elevators) || 'Ninguno', 
                    inline: true 
                },
                { 
                    name: 'Escaleras', 
                    value: this.formatEscalators(this.currentConfig.escalators) || 'Ninguna', 
                    inline: true 
                }
            )
            .setFooter({ text: 'Responde con "editar [tipo] [id]" o "añadir [tipo]" o "cancelar"' });

        return this.message.reply({ embeds: [embed] });
    }

    formatAccesses(accesses) {
        return accesses.map(a => `• ${a.name} (${a.id})`).join('\n') || 'Ninguno';
    }

    formatElevators(elevators) {
        return elevators.map(e => `• ${e.id}: ${e.from} → ${e.to}`).join('\n') || 'Ninguno';
    }

    formatEscalators(escalators) {
        return escalators.map(e => `• ${e.id}: ${e.from} → ${e.to}`).join('\n') || 'Ninguna';
    }

    async promptForConfiguration(message, stationKey, currentConfig) {
        const embed = new EmbedBuilder()
            .setColor(0xFFFF00)
            .setTitle(`🛗 Configuración inicial para ${currentConfig.station} ${currentConfig.line}`)
            .setDescription([
                '**Formato requerido:**',
                '```',
                'Accesos: Acceso A (Descripción: Ubicación), Acceso B',
                'Ascensores: ID: From→To, From→To, ID2: From→To',
                'Escaleras: ID: From→To, From→To',
                '```',
                'Ejemplo real:',
                '```',
                'Accesos: Acceso A (Descripción: Av. Alameda), Acceso B (Descripción: Av. María Rozas)',
                'Ascensores: LD: Andén Los Dominicos→Boletería, SP: Andén San Pablo→Boletería',
                'Escaleras: 1: Andén→Boletería, 2: Boletería→Calle',
                '```',
                'Separa múltiples elementos con comas. Escribe "cancelar" para terminar.'
            ].join('\n'));

        const prompt = await message.reply({ embeds: [embed] });
        return this.waitForInitialConfiguration(message, prompt, stationKey, currentConfig);
    }

    async waitForInitialConfiguration(message, prompt, stationKey, currentConfig) {
        const MAX_ATTEMPTS = 3;
        let attempts = 0;
        
        while (attempts < MAX_ATTEMPTS) {
            try {
                const responses = await message.channel.awaitMessages({
                    filter: m => m.author.id === message.author.id,
                    max: 1,
                    time: 300000,
                    errors: ['time']
                });

                const response = responses.first().content;
                if (response.toLowerCase() === 'cancelar') {
                    return this.sendSuccess(message, '❌ Configuración cancelada');
                }

                const config = await this.parseConfigurationInput(response, currentConfig.station, currentConfig.line);
                
                if (config.accesses.length === 0) {
                    throw new Error("Debe incluir al menos 1 acceso");
                }

                const confirm = await this.promptForConfirmation(
                    message,
                    "**Resumen de configuración:**\n" +
                    this.renderConfigPreview(config) +
                    "\n¿Confirmar esta configuración? (sí/no/cancelar)"
                );

                if (confirm.toLowerCase() === 'cancelar') {
                    return this.sendSuccess(message, '❌ Configuración cancelada');
                } else if (confirm.toLowerCase() === 'sí' || confirm.toLowerCase() === 'si') {
                    config.changeHistory = [{
                        timestamp: new Date().toISOString(),
                        user: message.author.tag,
                        action: 'Configuración inicial',
                        details: 'Creación de archivo de accesibilidad'
                    }];

                    await this.saveAccessConfig(stationKey, config);
                    return this.sendSuccess(message, `✅ Configuración guardada para ${config.station} ${config.line}`);
                } else {
                    attempts++;
                    await message.reply(`Intento ${attempts}/${MAX_ATTEMPTS}. Por favor reintente.`);
                }
            } catch (error) {
                if (error.name === 'TimeoutError') {
                    return this.sendError(message, 'Tiempo agotado. Por favor intenta nuevamente.');
                }
                attempts++;
                await message.reply(
                    `❌ Error: ${error.message}\n` +
                    `Intento ${attempts}/${MAX_ATTEMPTS}. Por favor corrija:\n` +
                    "Ejemplo válido:\n" +
                    "```\n" +
                    "Accesos: Acceso A (Descripción: Ubicación), Acceso B\n" +
                    "Ascensores: A: Calle→Boletería, Boletería→Andén\n" +
                    "```\n" +
                    "Escribe 'cancelar' para terminar."
                );
            }
        }
        
        return this.sendError(message, 'Máximo de intentos alcanzado. Comando cancelado.');
    }

    async parseConfigurationInput(input, stationName, line) {
        const config = {
            station: stationName,
            line: line,
            accesses: [],
            elevators: [],
            escalators: [],
            lastUpdated: new Date().toISOString(),
            changeHistory: []
        };

        const clean = (str) => str.trim().replace(/\s+/g, ' ');

        // Parse Access Points
        const accessSection = input.match(/Accesos:\s*([^]*?)(?=\nAscensores:|$)/is);
        if (accessSection) {
            config.accesses = accessSection[1].split(',')
                .map(item => {
                    const trimmed = clean(item);
                    if (!trimmed) return null;
                    
                    const descMatch = trimmed.match(/(.*?)\s*\(Descripción:\s*([^)]+)\)/i);
                    const name = descMatch ? clean(descMatch[1]) : trimmed;
                    const description = descMatch ? clean(descMatch[2]) : '';
                    
                    let id = name.startsWith('Acceso ') 
                        ? name.split(' ')[1] 
                        : name.replace(/Acceso/gi, '').trim();
                    
                    id = id.replace(/[^a-z0-9áéíóúñ]/gi, '');

                    return {
                        id,
                        name,
                        description,
                        status: 'abierto',
                        lastUpdated: new Date().toISOString(),
                        notes: ''
                    };
                })
                .filter(Boolean);
        }

        // Parse Elevators
        const elevatorSection = input.match(/Ascensores:\s*([^]*?)(?=\nEscaleras:|$)/is);
        if (elevatorSection) {
            const normalizedInput = elevatorSection[1].replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
            const elevatorEntries = normalizedInput.split(/(?<=]),\s*(?=[A-Za-z0-9]+:)|(?<=\S)\s+(?=[A-Za-z0-9]+:)/);
            
            for (const entry of elevatorEntries) {
                const colonIndex = entry.indexOf(':');
                if (colonIndex === -1) continue;
                
                const id = clean(entry.substring(0, colonIndex));
                const pathStr = clean(entry.substring(colonIndex + 1));
                
                if (!id || !pathStr) continue;
                
                try {
                    const { from, to, fullPath, segments } = this.parsePath(pathStr);
                    config.elevators.push({
                        id,
                        from,
                        to,
                        fullPath,
                        segments,
                        status: 'operativa',
                        lastUpdated: new Date().toISOString(),
                        notes: ''
                    });
                } catch (error) {
                    console.error(`Error parsing elevator ${id}: ${pathStr} - ${error.message}`);
                }
            }
        }

        // Parse Escalators
        const escalatorSection = input.match(/Escaleras:\s*([^]*?)(?=\n|$)/is);
        if (escalatorSection) {
            const normalizedInput = escalatorSection[1].replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
            const escalatorEntries = normalizedInput.split(/(?<=]),\s*(?=[A-Za-z0-9]+:)|(?<=\S)\s+(?=[A-Za-z0-9]+:)/);
            
            for (const entry of escalatorEntries) {
                const colonIndex = entry.indexOf(':');
                if (colonIndex === -1) continue;
                
                const id = clean(entry.substring(0, colonIndex));
                const pathStr = clean(entry.substring(colonIndex + 1));
                
                if (!id || !pathStr) continue;
                
                try {
                    const { from, to, fullPath, segments } = this.parsePath(pathStr);
                    config.escalators.push({
                        id,
                        from,
                        to,
                        fullPath,
                        segments,
                        status: 'operativa',
                        lastUpdated: new Date().toISOString(),
                        notes: ''
                    });
                } catch (error) {
                    console.error(`Error parsing escalator ${id}: ${pathStr} - ${error.message}`);
                }
            }
        }

        if (config.accesses.length === 0) {
            throw new Error("Debe incluir al menos 1 acceso");
        }

        return config;
    }

    // Static method to get legacy references
    static getLegacyReferences(instance) {
        return {
            handleAdvancedEdit: instance.batch.handleAdvancedEdit.bind(instance),
            handleReplaceOperation: instance.batch.handleReplaceOperation.bind(instance),
            parseAdvancedEditParams: instance.batch.parseAdvancedEditParams.bind(instance),
            processBatchEdit: instance.batch.processBatchEdit.bind(instance)
        };
    }
}

module.exports = {
    ConfigureHandler,
    getLegacyFunctions: () => {
        const instance = ConfigureHandler();
        return ConfigureHandler.getLegacyReferences(instance);
    }
};