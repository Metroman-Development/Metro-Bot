// modules/metro/data/framework/MetroDataFramework.js
const fs = require('fs').promises;
const path = require('path');
const EventEmitter = require('events');

class MetroDataFramework {
  constructor(options = {}) {
    // Configuration
    this.basePath = options.basePath || './metro-data/stations';
    this.autoGenerate = options.autoGenerate !== false;
    this.emitter = options.emitter || new EventEmitter();

    // State
    this.loadedData = {
      stations: {},
      lines: {}
    };
  }

  /** Public API **/

  async loadNetwork() {
    try {
      await this._ensureBaseStructure();
      
      // Load all line directories
      const lineDirs = await this._getLineDirectories();
      
      // Process each line
      for (const lineId of lineDirs) {
        await this._loadLine(lineId);
      }

      return this.loadedData;
    } catch (error) {
      this.emitter.emit('error', error);
      throw error;
    }
  }

  async getStation(lineId, stationId) {
    const stationKey = this._createStationKey(lineId, stationId);
    return this.loadedData.stations[stationKey] || null;
  }

  async updateStation(lineId, stationId, data) {
    const stationPath = this._getStationPath(lineId, stationId);
    const stationKey = this._createStationKey(lineId, stationId);

    try {
      // Ensure line directory exists
      await this._ensureLineDirectory(lineId);
      
      // Save to filesystem
      await fs.writeFile(
        stationPath,
        JSON.stringify(data, null, 2),
        'utf8'
      );

      // Update in-memory data
      this.loadedData.stations[stationKey] = data;

      this.emitter.emit('stationUpdated', { lineId, stationId });
      return true;
    } catch (error) {
      this.emitter.emit('error', error);
      throw error;
    }
  }

  async saveLine(lineData) {
    try {
      this.loadedData.lines[lineData.id] = lineData;
      this.emitter.emit('lineUpdated', lineData.id);
      return true;
    } catch (error) {
      this.emitter.emit('error', error);
      throw error;
    }
  }

  /** Internal Methods **/

  async _loadLine(lineId) {
    const linePath = path.join(this.basePath, lineId);
    const stationFiles = await this._getStationFiles(lineId);

    for (const stationFile of stationFiles) {
      const stationId = path.basename(stationFile, '.json');
      const stationKey = this._createStationKey(lineId, stationId);
      
      try {
        const data = await fs.readFile(
          path.join(linePath, stationFile),
          'utf8'
        );
        this.loadedData.stations[stationKey] = JSON.parse(data);
      } catch (error) {
        if (this.autoGenerate && error.code === 'ENOENT') {
          // Auto-generate missing station
          this.loadedData.stations[stationKey] = this._createDefaultStation(lineId, stationId);
        } else {
          throw error;
        }
      }
    }
  }

  async _ensureBaseStructure() {
    try {
      await fs.access(this.basePath);
    } catch {
      await fs.mkdir(this.basePath, { recursive: true });
    }
  }

  async _ensureLineDirectory(lineId) {
    const linePath = path.join(this.basePath, lineId);
    try {
      await fs.access(linePath);
    } catch {
      await fs.mkdir(linePath, { recursive: true });
    }
  }

  async _getLineDirectories() {
    try {
      const items = await fs.readdir(this.basePath);
      return items.filter(item => 
        item.match(/^l[1-6]$|^l4a$/i) && 
        !item.includes('.')
      );
    } catch {
      return [];
    }
  }

  async _getStationFiles(lineId) {
    try {
      const linePath = path.join(this.basePath, lineId);
      const items = await fs.readdir(linePath);
      return items.filter(item => 
        item.endsWith('.json') && 
        !item.startsWith('.')
      );
    } catch {
      return [];
    }
  }

  _createStationKey(lineId, stationId) {
    return `${lineId.toLowerCase()}:${stationId.toLowerCase()}`;
  }

  _getStationPath(lineId, stationId) {
    return path.join(
      this.basePath,
      lineId.toLowerCase(),
      `${stationId.toLowerCase()}.json`
    );
  }

  _createDefaultStation(lineId, stationId) {
    return {
      _meta: {
        version: 1,
        generatedAt: new Date().toISOString()
      },
      basicInfo: {
        id: stationId,
        lineId,
        name: stationId.replace(/_/g, ' '),
        status: "unknown"
      }
    };
  }
}

module.exports = MetroDataFramework;