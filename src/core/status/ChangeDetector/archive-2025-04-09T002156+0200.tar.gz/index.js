// modules/status/ChangeDetector/index.js
// modules/status/ChangeDetector/index.js
const EventEmitter = require('events');
const DatabaseHandler = require('./lib/DatabaseHandler');
const ChangeAnalyzer = require('./lib/ChangeAnalyzer');
const EventManager = require('./lib/EventManager');
const StateManager = require('./lib/StateManager');
const PerformanceTracker = require('./lib/PerformanceTracker');
const EventRegistry = require('../../../core/EventRegistry');
const logger = require('../../../events/logger');
const { performance } = require('perf_hooks');
const crypto = require('crypto');

class ChangeDetector extends EventEmitter {
    constructor(metroCore) {
        super();
        
        // Core Properties
        this.metroCore = metroCore;
        this.instanceId = crypto.randomBytes(4).toString('hex');
        this.startTime = Date.now();
        this.tableName = 'metro_status';
        this.debugMode = true;
        this.trueFirstRun = true;

        // System State
        this._isPaused = false;
        this._pendingData = null;
        this._pendingChanges = [];
        this._pauseTimer = null;
        this.dataGate = true;

        // Initialize modules with dependency injection
        this._dbHandler = new DatabaseHandler(this);
        this._stateManager = new StateManager(this);
        this._eventManager = new EventManager(this);
        this._performance = new PerformanceTracker(this);
        this._analyzer = new ChangeAnalyzer(this);

        // Bindings
        this._handleDataProcessed = this._handleDataProcessed.bind(this);
        this._processPendingData = this._processPendingData.bind(this);

        // Setup core listeners
        this._setupMetroCoreListeners();
    }

    /*======================*/
    /*  PUBLIC API          */
    /*======================*/

    async initialize() {
        try {
            
            console.log("Booting 7p ChangeDetector")
            // Initialize database connection
            await this._dbHandler.initialize();
            
            // Load last known state
            const lastState = await this._dbHandler.getLastState();
            if (lastState) {
                this._stateManager.updateState(lastState);
            }

            // Emit system ready event
            await this._eventManager.emitSystemEvent(EventRegistry.READY, {
                version: process.env.npm_package_version,
                initialState: !!lastState,
                dbStatus: this._dbHandler.getStatus()
            });

            // Open data gate if not paused
            if (!this._isPaused) {
                this.openDataGate();
            }

            return true;
        } catch (error) {
            await this._eventManager.emitSystemEvent(EventRegistry.ERROR, {
                error: error.message,
                stack: error.stack,
                phase: 'initialization'
            });
            throw error;
        }
    }

    async analyze(data) {
        const startTime = performance.now();
        try {
            const result = await this._analyzer.analyze(data);
            this._performance.recordAnalysis(performance.now() - startTime);
            return result;
        } catch (error) {
            await this._eventManager.emitSystemEvent(EventRegistry.ERROR, {
                error: error.message,
                stack: error.stack,
                phase: 'analysis',
                dataVersion: data?.version
            });
            throw error;
        }
    }

    openDataGate() {
        if (!this.dataGate) {
            this.dataGate = true;
            this._eventManager.openDataGate();
            logger.debug(`[${this.instanceId}] Data gate opened`, {
                pendingChanges: this._pendingChanges.length
            });
        }
    }

    closeDataGate() {
        if (this.dataGate) {
            this.dataGate = true;
            logger.debug(`[${this.instanceId}] Data gate closed`);
        }
    }

    pauseFor(ms = 30000) {
        if (this._isPaused) return;

        this._isPaused = true;
        this.closeDataGate();
        
        this._pauseTimer = setTimeout(() => this.resume(), ms).unref();
        
        this._eventManager.emitSystemEvent(EventRegistry.STATE_CHANGE, {
            state: 'paused',
            duration: ms,
            reason: 'scheduled_maintenance'
        });
    }

    resume() {
        if (!this._isPaused) return;

        clearTimeout(this._pauseTimer);
        this._isPaused = false;
        this.openDataGate();
        this._processPendingData();

        this._eventManager.emitSystemEvent(EventRegistry.STATE_CHANGE, {
            state: 'active',
            pendingData: !!this._pendingData
        });
    }

    getDiagnostics() {
        return {
            instanceId: this.instanceId,
            uptime: Date.now() - this.startTime,
            isPaused: this._isPaused,
            dataGate: this.dataGate,
            pendingData: !!this._pendingData,
            pendingChanges: this._pendingChanges.length,
            statistics: this._stateManager.statistics,
            performance: this._performance.stats,
            lastStateVersion: this._stateManager.lastProcessedVersion,
            database: this._dbHandler.getStatus(),
            listeners: this._getActiveListeners()
        };
    }

    destroy() {
        // Clear timers and queues
        clearTimeout(this._pauseTimer);
        this._pendingData = null;
        this._pendingChanges = [];

        // Cleanup modules
        this._eventManager.cleanup();
        this._dbHandler.disconnect();
        
        // Remove listeners
        this._cleanupListeners();
        this.removeAllListeners();

        this._eventManager.emitSystemEvent(EventRegistry.SHUTDOWN, {
            uptime: Date.now() - this.startTime
        });
    }

    /*======================*/
    /*  PRIVATE METHODS     */
    /*======================*/

    _setupMetroCoreListeners() {
        this._cleanupListeners();
        this.metroCore.on(EventRegistry.DATA_PROCESSED, this._handleDataProcessed);
    }

    _cleanupListeners() {
        this.metroCore.off(EventRegistry.DATA_PROCESSED, this._handleDataProcessed);
    }

    async _handleDataProcessed(payload) {
        if (!payload.validate()) {
            logger.warn(`[${this.instanceId}] Invalid data payload`, {
                errors: payload.errors
            });
            return;
        }

        if (this._isPaused) {
            this._pendingData = payload.data;
            logger.debug(`[${this.instanceId}] Data queued during pause`, {
                version: payload.data.version
            });
            return;
        }

        try {
            await this.analyze(payload.data);
        } catch (error) {
            logger.error(`[${this.instanceId}] Data processing failed`, {
                error: error.message,
                version: payload.data.version
            });
        }
    }

    _processPendingData() {
        if (this._pendingData) {
            const data = this._pendingData;
            this._pendingData = null;
            this.analyze(data)
                .catch(error => logger.error(`[${this.instanceId}] Pending data processing failed`, error));
        }
    }

    _getActiveListeners() {
        return {
            metroCore: this.metroCore.eventNames().map(name => ({
                event: name,
                count: this.metroCore.listenerCount(name)
            })),
            internal: this.eventNames().map(name => ({
                event: name,
                count: this.listenerCount(name)
            }))
        };
    }

    /*======================*/
    /*  COMPATIBILITY LAYER */
    /*======================*/

    // Legacy property accessors
    get performanceStats() {
        logger.warn('Deprecated: Use getDiagnostics().performance instead');
        return this._performance.stats;
    }

    get changeStatistics() {
        logger.warn('Deprecated: Use getDiagnostics().statistics instead');
        return this._stateManager.statistics;
    }

    getRecentChanges() {return this._analyzer.getRecentChanges()}
    
    
    get lastState() {
        logger.warn('Deprecated: Use stateManager.lastState instead');
        return this._stateManager.lastState;
    }
}

module.exports = ChangeDetector;