// modules/status/utils/changeUtils.js
const logger = require('../../../../events/logger');

/**
 * Calculates the severity level based on status changes
 * @param {Object} changes - Detected changes object
 * @returns {string} Highest severity level ('low', 'medium', 'high', 'critical')
 */
function calculateSeverity(changes) {
    const severityWeights = {
        'operational': 0,
        'delayed': 1,
        'partial_outage': 2,
        'major_outage': 3
    };

    let maxSeverity = 0;

    // Check line changes
    if (changes.lines && changes.lines.length > 0) {
        changes.lines.forEach(change => {
            const weight = severityWeights[change.normalizedTo] || 0;
            if (weight > maxSeverity) {
                maxSeverity = weight;
            }
        });
    }

    // Check station changes
    if (changes.stations && changes.stations.length > 0) {
        changes.stations.forEach(change => {
            const weight = severityWeights[change.normalizedTo] || 0;
            if (weight > maxSeverity) {
                maxSeverity = weight;
            }
        });
    }

    // Map to severity levels
    switch(maxSeverity) {
        case 3: return 'critical';
        case 2: return 'high';
        case 1: return 'medium';
        default: return 'low';
    }
}

/**
 * Groups consecutive stations with the same status change
 * @param {Array} stations - Array of station change objects
 * @returns {Array} Array of grouped station changes
 */
function groupConsecutiveStations(stations) {
    if (!stations || stations.length === 0) return [];

    const groups = [];
    let currentGroup = {
        line: stations[0].line,
        from: stations[0].from,
        to: stations[0].to,
        stations: [stations[0].id],
        count: 1
    };

    for (let i = 1; i < stations.length; i++) {
        const current = stations[i];
        const lastInGroup = stations[i-1];

        // Check if we can extend the current group
        if (current.line === lastInGroup.line &&
            current.from === lastInGroup.from &&
            current.to === lastInGroup.to &&
            current.id === lastInGroup.id + 1) {
            
            currentGroup.stations.push(current.id);
            currentGroup.count++;
        } else {
            // Finalize current group
            groups.push(currentGroup);
            
            // Start new group
            currentGroup = {
                line: current.line,
                from: current.from,
                to: current.to,
                stations: [current.id],
                count: 1
            };
        }
    }

    // Add the last group
    groups.push(currentGroup);

    logger.debug(`Grouped ${stations.length} stations into ${groups.length} groups`);
    return groups;
}

/**
 * Determines if a change is significant enough to trigger alerts
 * @param {Object} change - Single change object
 * @returns {boolean} True if significant
 */
function isSignificantChange(change) {
    const insignificantTransitions = [
        ['operational', 'delayed'],
        ['delayed', 'operational']
    ];

    const transition = [change.normalizedFrom, change.normalizedTo].join(',');
    return !insignificantTransitions.includes(transition);
}

module.exports = {
    calculateSeverity,
    groupConsecutiveStations,
    isSignificantChange
};