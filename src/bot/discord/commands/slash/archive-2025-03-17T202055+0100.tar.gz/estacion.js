const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const { deepSearch } = require('../utils/searchUtils');

const { getStation } = require('../utils/dataUtils'); // Use getStation from dataUtils

const logger = require('../events/logger'); // Import the logger

module.exports = {

    data: new SlashCommandBuilder()

        .setName('estacion')

        .setDescription('Muestra información de una estación de metro')

        .addStringOption(option =>

            option.setName('nombre')

                .setDescription('Nombre de la estación')

                .setAutocomplete(true)

                .setRequired(true)),

    

    async autocomplete(interaction) {

        const query = interaction.options.getFocused();

        logger.info(`Autocomplete triggered for query: ${query}`);

        

        try {

            const matches = await deepSearch(query, { maxResults: 25 });

            await interaction.respond(matches.map(m => ({

                name: `${m.name} (Línea ${m.line})`, // Use m.name instead of m.nombre

                value: m.name // Use m.name as the value

            })));

        } catch (error) {

            logger.error(interaction.client, `Error during autocomplete: ${error.message}`);

        }

    },

    async execute(interaction) {
    const fullQuery = interaction.options.getString('nombre');

    // Parse query into name and optional line
    const lineSuffixRegex = /(?:\s+|\b)(L\d+[a-zA-Z]*)$/i;
    const lineMatch = fullQuery.match(lineSuffixRegex);
    let name, line;

    if (lineMatch) {
        name = fullQuery.replace(lineSuffixRegex, '').trim();
        line = lineMatch[1].replace(/L/gi, ''); // Extract "1" from "L1"
    } else {
        // If no line is specified, use the full query as the name
        name = fullQuery.trim();
        line = null; // Line is optional
    }

    try {
        // Use deepSearch to find the station by name
        const searchResults = await deepSearch(name, { needsOneMatch: true, interaction });

        if (!searchResults || searchResults.length === 0) {
            logger.warn(`No matches found for query: ${name}`);
            return interaction.followUp('Estación no encontrada');
        }

        // Get the first match from searchResults
        const firstMatch = searchResults[0];

        // Fetch detailed station data using getStation from dataUtils
        const detailedStation = getStation(firstMatch.name); // Use firstMatch.name

        if (!detailedStation) {
            logger.warn(`No detailed data found for station: ${firstMatch.name}`);
            return interaction.followUp('No se pudo obtener información detallada de la estación');
        }

        // Create the embed using createEmbed
        const embed = createEmbed(detailedStation);

        // Send the embed as a response
        await interaction.followUp({ embeds: [embed] });
        logger.info(`Station information displayed for: ${detailedStation.original}`);
    } catch (error) {
        console.log(error);
        logger.error(interaction.client, `Error during station search: ${error.message}`);
        interaction.followUp('Ocurrió un error al buscar la estación. Por favor, inténtalo de nuevo.');
    }
}

};

// Creates the embed for displaying station information

function createEmbed(station) {

    return new EmbedBuilder()

        .setTitle(`🚉 ${station.original} (Línea ${station.line})`)

        .addFields(

            { name: 'Estado', value: station.status.description === 'Habilitada' ? '🟢 Operativa' : '🔴 Cerrada', inline: true },

            { name: 'Conexiones', value: station.transfer ? `L${station.transfer}` : 'Ninguna', inline: true },

            { name: 'Servicios', value: station.details.services.join('\n') || 'N/A', inline: false },

            { name: 'Accesibilidad', value: station.details.accessibility || 'Sin información', inline: true },

            { name: 'Comercios', value: station.details.amenities.join(', ') || 'Ninguno', inline: true },

            { name: 'Comuna', value: station.details.municipality || 'Desconocido', inline: true }

        )

        .setImage(station.details.schematics[0] || '') // Use the first schematic image if available

        .setColor(station.status.description === 'Habilitada' ? '#00FF00' : '#FF0000');

} 