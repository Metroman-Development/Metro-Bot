// In your command handler
const MigrationManager = require('../../modules/metro/data/MigrationManager');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    parentCommand: 'owner',
    
    data: (subcommand) => subcommand
        .setName('metrodata')
        .setDescription('Control Administrativo sobre los archivos de datos')
        .addStringOption(option =>
            option.setName('action')
                .setDescription('Acción a realizar')
                .setRequired(true)
                .addChoices(
                    { name: 'Migrar datos', value: 'migrate' },
                    { name: 'Revertir migración', value: 'rollback' }
                ))
        .addBooleanOption(option =>
            option.setName('dry-run')
                .setDescription('Ejecutar en modo prueba sin cambios reales')
                .setRequired(false)),
    
    async execute(interaction) {
        const migrator = new MigrationManager();
        await interaction.deferReply({ ephemeral: true });

        const action = interaction.options.getString('action');
        const dryRun = interaction.options.getBoolean('dry-run') ?? false;

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setFooter({ text: `Comando ejecutado por ${interaction.user.username}` })
            .setTimestamp();

        try {
            if (action === 'migrate') {
                const result = await migrator.migrateAllData();
                embed.setTitle('🚀 Migración Completada')
                    .setDescription("Éxito")
                    .addFields(
                        { name: 'Estaciones procesadas', value: result.stations?.length() || "Naida" , inline: true },
                        { name: 'Líneas afectadas', value: result.lines?.join(', ') || "Naida" , inline: true }
                    );
            } 
            else if (action === 'rollback') {
                const result = await migrator.handleRollback();
                embed.setTitle('⏪ Reversión Completada')
                    .addFields(
                        { name: 'Estaciones revertidas', value: result.stations.toString(), inline: true },
                        { name: 'Versión restaurada', value: result.version, inline: true }
                    );
            }

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            await interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setColor('#ff0000')
                        .setTitle('❌ Error en la operación')
                        .setDescription(`\`\`\`${error.message}\`\`\``)
                ],
                ephemeral: true
            });
            console.error(`Metrodata command failed:`, error);
        }
    }
};