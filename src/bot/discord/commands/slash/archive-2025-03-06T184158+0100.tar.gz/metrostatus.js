const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('metrostatus')
        .setDescription('Get the status of a Metro station or an entire line.')
        .addStringOption(option =>
            option.setName('input')
                .setDescription('Enter a station name or line code (e.g., L1, L2).')
                .setRequired(true)), // Input is mandatory
    async execute(interaction) {
        const userInput = interaction.options.getString('input').toLowerCase();

        try {
            // Fetch data from the Metro API
            const response = await fetch('https://www.metro.cl/api/estadoRedDetalle.php');
            if (!response.ok) {
                throw new Error('Failed to fetch data from the Metro API.');
            }

            const data = await response.json();

            // Check if input matches a line
            if (data[userInput]) {
                const line = data[userInput];
                const embed = new EmbedBuilder()
                    .setTitle(`Metro Line Status: ${userInput.toUpperCase()}`)
                    .setDescription(line.mensaje_app)
                    .setColor(line.estado === '1' ? 0x57F287 : 0xED4245) // Green for available, red for issues
                    .addFields(line.estaciones.map(station => ({
                        name: station.nombre,
                        value: `Status: ${station.descripcion_app}\nCombination: ${station.combinacion || 'None'}`,
                        inline: true,
                    })));

                return interaction.reply({ embeds: [embed] });
            }

            // Otherwise, look for a specific station
            let stationFound = null;
            for (const key in data) {
                const line = data[key];
                stationFound = line.estaciones.find(station => station.nombre.toLowerCase() === userInput);
                if (stationFound) break;
            }

            if (!stationFound) {
                return interaction.reply({
                    content: `No station or line found matching **${userInput}**. Please check the spelling or input.`,
                    ephemeral: true,
                });
            }

            // Create an embed for the station's status
            const embed = new EmbedBuilder()
                .setTitle(`Metro Station Status: ${stationFound.nombre}`)
                .addFields(
                    { name: 'Status', value: stationFound.descripcion_app, inline: true },
                    { name: 'Combination', value: stationFound.combinacion || 'None', inline: true }
                )
                .setDescription(stationFound.mensaje || 'No additional notes')
                .setColor(stationFound.estado === '1' ? 0x57F287 : 0xED4245);

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Error fetching Metro status:', error);
            await interaction.reply({
                content: 'There was an error fetching the Metro status. Please try again later.',
                ephemeral: true,
            });
        }
    },
};