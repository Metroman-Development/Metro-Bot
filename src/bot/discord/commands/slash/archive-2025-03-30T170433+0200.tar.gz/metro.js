const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('metro')
        .setDescription('Replies with Man!'),
    active: true, // Add this line to allow dynamic activation/deactivation
    category: "Diversión", 
    async execute(interaction) {
        
        await interaction.followUp('Man!');
    },
};