const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const timeUtils = require('../utils/timeUtils');
const metroConfig = require('../config/metroConfig');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('horario')
        .setDescription('Muestra el horario completo del Metro e indica qué horario está activo actualmente.'),
    
    category: "Metro Info", 
    
    async execute(interaction) {
        // Get the current day and time
        const currentDay = timeUtils.getCurrentDay();
        const currentTime = timeUtils.getCurrentTime();

        // Determine the active schedule
        let activeSchedule;
        if (currentDay === 'Sábado') {
            activeSchedule = 'Sábado';
        } else if (currentDay === 'Domingo' || timeUtils.isFestiveDay()) {
            activeSchedule = 'Domingo';
        } else {
            activeSchedule = 'Semana';
        }

        // Get the operating hours
        const horario = metroConfig.horario;

        // Create the embed
        const embed = new EmbedBuilder()
            .setTitle('🚇 Horario del Metro de Santiago')
            .setDescription(`**Horario Actualmente Activo:** ${activeSchedule}`)
            .setColor(0x0099FF) // Blue color
            .addFields(
                { name: '📅 Semana (Lunes a Viernes)', value: `${horario.Semana[0]} - ${horario.Semana[1]}`, inline: true },
                { name: '📅 Sábado', value: `${horario.Sábado[0]} - ${horario.Sábado[1]}`, inline: true },
                { name: '📅 Domingo y Festivos', value: `${horario.Domingo[0]} - ${horario.Domingo[1]}`, inline: true },
            )
            .setFooter({ text: 'Metro de Santiago - Información actualizada en tiempo real' })
            .setTimestamp();

        // Reply with the embed
        await interaction.followUp({ embeds: [embed] });
    },
};