// slashCommands/tarifario.js
const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createFareEmbed } = require('../config/defaultEmbeds/fareEmbeds');
const { getCurrentDay, getCurrentTime, getCurrentFarePeriod } = require('../utils/timeUtils');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tarifario')
        .setDescription('Muestra las tarifas actuales del Metro.'),
    active: true,
    category: "Planifica tu Viaje",

    async execute(interaction) {
        
        console.log("Retrieving Time Settings");
        const currentTime = getCurrentTime();
        console.log("Success") 
        const currentDay = getCurrentDay();
        console.log("Success");
        const currentPeriod = getCurrentFarePeriod();
        
        console.log("Retrieve ID's");

        // Generate a unique embedId for this interaction
        const userId = interaction.user.id;
        const embedId = `${userId}_${interaction.id}`;
        
       console.log("Building buttons") ;

        // Create buttons for switching fare types
        const row1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`fareButtons_${userId}_${embedId}_metro`) // Custom ID with prefix, userId_embedId, and action
                .setEmoji('🚇')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`fareButtons_${userId}_${embedId}_combinacion`) // Custom ID with prefix, userId_embedId, and action
                .setEmoji('🔄')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`fareButtons_${userId}_${embedId}_estudiante`) // Custom ID with prefix, userId_embedId, and action
                .setEmoji('🎓')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`fareButtons_${userId}_${embedId}_adulto`) // Custom ID with prefix, userId_embedId, and action
                .setEmoji('👴')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`fareButtons_${userId}_${embedId}_adultobip`) // Custom ID with prefix, userId_embedId, and action
                .setEmoji('💳')
                .setStyle(ButtonStyle.Primary)
        );

        const row2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`fareButtons_${userId}_${embedId}_transantiago`) // Custom ID with prefix, userId_embedId, and action
                .setEmoji('🚌')
                .setStyle(ButtonStyle.Primary)
        );
        
        console.log("Sending Embed");

        // Send the initial embed with buttons
        await interaction.followUp({
            embeds: [createFareEmbed('metro', currentDay, currentTime, currentPeriod)],
            components: [row1, row2],
        });
    },
};

