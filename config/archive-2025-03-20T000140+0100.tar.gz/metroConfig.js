  module.exports = {
      
       // Channel IDs

    updatesChannelId: '1347146518943105085', // For new updates/announcements
      
    welcomeChannelID:
      '899844115934642176' , 

    embedsChannelId: '1011417825862226023',   // For permanent embeds

    // Message IDs for the 8 embeds in the embedsChannel

    embedMessageIds: {

        overview : '1349131665842376725', // Overview embed

        l1 : '1349131668673269761',     // Line 1

        l2 : '1349131671517008037',     // Line 2

        l3 : '1349131673249251431' ,     // Line 3

        l4 : '1349131675631616093',     // Line 4

        l4a : '1349131677753938056',    // Line 4A

       
        l5 : '1349131680429904024', 
  // Line 5

        l6 : '1349131682506211330'      // Line 6

    },
    // Emojis for each Metro line
    linesEmojis: {
        'l1': '<:Linea1:900165458412585000>',
        'l2': '<:Linea2:900165548107784202>',
        'l3': '<:Linea3:900165548707561482>',
        'l4': '<:Linea4:900165548460081212>',
        'l4a': '<:Linea4A:900165409234386944>',
        'l5': '<:Linea5:900166003936329768>',
        'l6': '<:Linea6:900166219435499560>',
    },

      
      
   
    // Mapping for station statuses
    statusMapping: {
        '1': { emoji: '🟩', message: 'Operativa' }, // Operational
        '2': { emoji: '🟥', message: 'Cerrada' },   // Closed
        '3': { emoji: '🟨', message: 'Cierre Parcial' }, // Partial Closure
        '4': { emoji: '⏲️', message: 'Demoras en Frecuencia' }, // Frequency Delays
    },

    // Icons for stations, sorted in the requested order
    stationIcons: {
        'cierre por horario' : { emoji: '🌙', message: 'Cierre por Horario'}, 
        'operativa': { emoji: '<:operativa:1348394413357010984>', message: 'Operativa' },
        'parcial': { emoji: '<:parcial:1348400125005008977>', message: 'Cierre Parcial' },
        'cerrada': { emoji: '<:cerrada:1348394347045064766>', message: 'Cierre Temporal' },
        'comun': { emoji: '<:comun:1348400171578425404>', message: 'Ruta Común' },
        'roja': { emoji: '<:roja:1348395124627083476>', message: 'Ruta Roja' },
        'verde': { emoji: '<:verde:1348394381928828993>', message: 'Ruta Verde' },
    },

    // Messages for `message_app`
    messageAppOverrides: {
        'Estación Operativa': '🔵 Operativa',
        'Estación Cerrada': '🔴 Cerrada',
        // Add more overrides as needed
    }, 

    

    // Metro operating hours
    horario: {
        Semana: ["6 AM", "11 PM"], // Weekdays
        Sábado: ["6:30 AM", "11 PM"], // Saturday
        Domingo: ["7:30 AM", "11 PM"], // Sunday
    },

    // API endpoint for Metro data
    apiEndpoint: 'https://www.metro.cl/api/estadoRedDetalle.php',
      
    logoMetroEmoji: "<:metrologo:1349494723760492594>", 
      
   // Metro operating hours

    horario: {

        Semana: ["6:00 AM", "11:00 PM"], // Weekdays

        Sábado: ["6:30 AM", "11:00 PM"], // Saturday

        Domingo: ["8:00 AM", "11:00 PM"], // Sunday

    },

    // Express route hours (only on weekdays)

    horarioExpreso: {

        morning: ["6:00 AM", "9:00 AM"], // Morning express

        evening: ["6:00 PM", "9:00 PM"], // Evening express

    },

    // Fare periods (PUNTA, VALLE, BAJO)

    horarioPeriodos: {
        PUNTA: [
            { inicio: "07:00:00", fin: "09:00:00" }, // Morning peak
            { inicio: "18:00:00", fin: "20:00:00" }, // Evening peak
        ],
        VALLE: [
            { inicio: "09:00:00", fin: "18:00:00" }, // Midday
            { inicio: "20:00:00", fin: "23:00:00" }, // Late evening
        ],
        BAJO: [
            { inicio: "06:00:00", fin: "07:00:00" }, // Early morning
            { inicio: "23:00:00", fin: "23:59:59" }, // Late night
        ],
        SERVICEHOURS: [
            { inicio: "06:00:00", fin: "23:00:00" }, // Weekdays
            { inicio: "06:30:00", fin: "23:00:00" }, // Saturday
            { inicio: "08:00:00", fin: "23:00:00" }, // Sunday
        ],
    },


    // Fare prices (in CLP)

    tarifario: {

        t_metro_punta: "870", // Peak fare

        t_metro_valle: "790", // Midday fare

        t_metro_bajo: "710", // Off-peak fare

        t_combinacion_punta: "870", // Combined peak fare

        t_combinacion_valle: "790", // Combined midday fare

        t_combinacion_bajo: "770", // Combined off-peak fare

        t_estudiante_punta: "250", // Student peak fare

        t_estudiante_valle: "250", // Student midday fare

        t_estudiante_bajo: "250", // Student off-peak fare

        t_adulto_punta: "250", // Adult peak fare

        t_adulto_valle: "250", // Adult midday fare

        t_adulto_bajo: "250", // Adult off-peak fare

        t_adultobip_punta: "370", // Adult BIP peak fare

        t_adultobip_valle: "370", // Adult BIP midday fare

        t_adultobip_bajo: "370", // Adult BIP off-peak fare

        t_nos_punta: "870", // NOS peak fare

        t_nos_valle: "790", // NOS midday fare

        t_nos_bajo: "710", // NOS off-peak fare

        t_transantiago: "700", // Transantiago fare

    },

    // Festive days (public holidays in Chile for 2025)

    festiveDays: [

        "2025-01-01", // New Year's Day

        "2025-04-18", // Good Friday

        "2025-04-19", // Holy Saturday

        "2025-05-01", // Labor Day

        "2025-05-21", // Navy Day

        "2025-06-29", // Saint Peter and Saint Paul

        "2025-07-16", // Our Lady of Mount Carmel

        "2025-08-15", // Assumption of Mary

        "2025-09-18", // Independence Day

        "2025-09-19", // Army Day

        "2025-10-12", // Columbus Day

        "2025-10-31", // Reformation Day

        "2025-11-01", // All Saints' Day

        "2025-12-08", // Immaculate Conception

        "2025-12-25", // Christmas Day

    ],
      
        
};