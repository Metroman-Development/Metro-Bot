// stationLoader.js
// stationLoader.js
const path = require('path');
const fs = require('fs').promises;
const config = require('../../../../config/metro/metroConfig');
const styles = require('../../../../config/metro/styles.json');
const estadoRedTemplate = require('../../../../templates/estadoRedDetalle.php.json');

module.exports = {
  source: 'stations.json + stationConnections.json + stationsData.json',
  async load() {
    const [stations, connections, data] = await Promise.all([
      this._loadFile('stations.json'),
      this._loadFile('stationConnections.json'),
      this._loadFile('stationsData.json')
    ]);
    return this._transform(stations, connections, data);
  },

  async _loadFile(filename) {
    try {
      const data = await fs.readFile(path.join(__dirname, '../json', filename), 'utf8');
      return JSON.parse(data);
    } catch (error) {
      console.error(`Error loading file ${filename}:`, error);
      throw error;
    }
  },

  _transform(rawStations, rawConnections, rawData) {
    // Create canonical station index from template
    const canonicalStations = this._createCanonicalIndex();
    const result = {};

    // Process all canonical stations first
    for (const [canonicalId, stationInfo] of Object.entries(canonicalStations)) {
      result[canonicalId] = {
        ...stationInfo,
        connections: this._getCanonicalConnections(canonicalId, stationInfo.line, rawConnections),
        _source: 'template'
      };
    }

    // Merge stations.json data
    for (const [lineId, lineStations] of Object.entries(rawStations)) {
      for (const [rawName, stationData] of Object.entries(lineStations)) {
        const canonicalId = this._findCanonicalId(rawName, lineId, canonicalStations) || 
                          this._createCanonicalId(rawName, lineId);
        
        if (!result[canonicalId]) {
          result[canonicalId] = this._createBasicStation(canonicalId, lineId);
        }

        result[canonicalId] = {
          ...result[canonicalId],
          ...stationData,
          _source: result[canonicalId]._source ? 
                  `${result[canonicalId]._source}+stations` : 'stations'
        };
      }
    }

    // Merge stationsData.json
    if (rawData?.stationsData) {
      for (const [rawName, stationData] of Object.entries(rawData.stationsData)) {
        const lineMatch = rawName.match(/(l[1-6]|l4a)$/i);
        const lineId = lineMatch ? lineMatch[0].toLowerCase() : null;
        const canonicalId = this._findCanonicalId(rawName, lineId, canonicalStations) || 
                          this._createCanonicalId(rawName, lineId || 'unknown');
        
        if (!result[canonicalId]) {
          result[canonicalId] = this._createBasicStation(canonicalId, lineId || 'unknown');
        }

        result[canonicalId] = {
          ...result[canonicalId],
          transports: stationData[0] || result[canonicalId].transports || 'None',
          services: stationData[1] || result[canonicalId].services || 'None',
          accessibility: stationData[2] || result[canonicalId].accessibility || 'None',
          commerce: stationData[3] || result[canonicalId].commerce || 'None',
          amenities: stationData[4] || result[canonicalId].amenities || 'None',
          image: stationData[5] || result[canonicalId].image || 'None',
          commune: stationData[6] || result[canonicalId].commune || 'None',
          _source: result[canonicalId]._source ? 
                  `${result[canonicalId]._source}+data` : 'data'
        };
      }
    }

    // Add schematics
    if (rawData?.stationsSchematics) {
      for (const [rawName, schematics] of Object.entries(rawData.stationsSchematics)) {
        const lineMatch = rawName.match(/(l[1-6]|l4a)$/i);
        const lineId = lineMatch ? lineMatch[0].toLowerCase() : null;
        const canonicalId = this._findCanonicalId(rawName, lineId, canonicalStations) || 
                          this._createCanonicalId(rawName, lineId || 'unknown');
        
        if (result[canonicalId]) {
          result[canonicalId].schematics = schematics;
        }
      }
    }

    return result;
  },

  _createCanonicalIndex() {
    const index = {};
    for (const [lineId, lineData] of Object.entries(estadoRedTemplate)) {
      for (const station of lineData.estaciones) {
        const canonicalId = station.nombre;
        index[canonicalId] = {
          id: canonicalId,
          line: lineId.toLowerCase(),
          displayName: station.nombre,
          code: station.codigo,
          status: {
              code: station.estado, 
              message: station.descripcion,
          
              appMessage: station.descripcion_app
             },
          color: styles.lineColors[lineId] || config.defaultLineColor,
          combination: station.combinacion || null
        };
      }
    }
    return index;
  },

  _findCanonicalId(rawName, lineId, canonicalStations) {
    // Try exact match first
    if (canonicalStations[rawName]) return rawName;
    
    // Try with line suffix if we have a lineId
    if (lineId) {
      const withSuffix = `${rawName} ${lineId.toUpperCase()}`;
      if (canonicalStations[withSuffix]) return withSuffix;
    }
    
    // Try to find closest match
    const normalizedRaw = this._normalizeName(rawName);
    for (const canonicalId in canonicalStations) {
      if (this._normalizeName(canonicalId) === normalizedRaw) {
        return canonicalId;
      }
    }
    
    return null;
  },

  _createCanonicalId(rawName, lineId) {
    return lineId && lineId !== 'unknown' ? 
      `${rawName} ${lineId.toUpperCase()}` : rawName;
  },

  _createBasicStation(canonicalId, lineId) {
    return {
      id: canonicalId,
      line: lineId.toLowerCase(),
      displayName: canonicalId,
      status: {message:'operational'} ,
      color: styles.lineColors[lineId] || config.defaultLineColor,
      connections: { transports: [], bikes: [] }
    };
  },

  _getCanonicalConnections(canonicalId, lineId, connectionsData) {
    const lineConnections = connectionsData[lineId]?.estaciones || [];
    
    // Try exact match first
    const exactMatch = lineConnections.find(s => 
      s.nombre === canonicalId
    );
    if (exactMatch) {
      return {
        transports: exactMatch.conexiones || [],
        bikes: exactMatch.bici || []
      };
    }
    
    // Try normalized match
    const normalizedCanonical = this._normalizeName(canonicalId);
    const normalizedMatch = lineConnections.find(s => 
      this._normalizeName(s.nombre) === normalizedCanonical
    );
    
    return normalizedMatch ? {
      transports: normalizedMatch.conexiones || [],
      bikes: normalizedMatch.bici || []
    } : { transports: [], bikes: [] };
  },

  _normalizeName(name) {
    return name
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/\s+/g, '_')
      .replace(/[^a-z0-9_]/g, '');
  }
};