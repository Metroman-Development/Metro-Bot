// modules/metro/core/services/ApiService.js
// modules/metro/core/services/ApiService.js
const EventEmitter = require('events');
const { fetch } = require('undici');
const crypto = require('crypto');
const fs = require('fs').promises;
const path = require('path');
const { performance } = require('perf_hooks');
const TimeHelpers = require('../../../chronos/timeHelpers');
const TimeAwaiter = require('../../../chronos/TimeAwaiter');
const logger = require('../../../../events/logger');
const EventRegistry = require('../../../../core/EventRegistry');
const EventPayload = require('../../../../core/EventPayload');
const config = require('../../../../config/metro/metroConfig');
const NewsService = require('./NewsService');
const StatusOverrideService = require('./StatusOverrideService');

class ApiService extends EventEmitter {
    constructor(metro, options = {}) {
        super();
        logger.debug('[ApiService] Initializing new instance');
        
        // Core configuration
        this.debug = options.debug || false;
        this.chaosFactor = options.chaosFactor || 2000;
        this._cycleCount = 0;
        this._statusOptions = {
            lineStatuses: {
                '1': { mensaje: 'Operativo', mensaje_app: 'Operational' },
                '2': { mensaje: 'Con demoras', mensaje_app: 'Delayed' },
                '3': { mensaje: 'Servicio parcial', mensaje_app: 'Partial service' },
                '4': { mensaje: 'Suspendido', mensaje_app: 'Suspended' }
            },
            stationStatuses: {
                '1': { descripcion: 'Operativa', descripcion_app: 'Operational' },
                '2': { descripcion: 'Con demoras', descripcion_app: 'Delayed' },
                '3': { descripcion: 'Servicio parcial', descripcion_app: 'Partial service' },
                '4': { descripcion: 'Suspendida', descripcion_app: 'Suspended' }
            }
        };

        // Initialize services
        this.timeHelpers = TimeHelpers;
        this.newsService = new NewsService(metro);
        this.override = new StatusOverrideService();

        // Path configuration
        this.cacheDir = path.join(__dirname, '../../../../data');
        this.cacheFile = path.join(this.cacheDir, '/cache/network-status.json');
        this.processedDataFile = path.join(this.cacheDir, 'processedEstadoRed.php.json');
        this.legacyCacheFile = path.join(__dirname, '../../../../data/estadoRedDetalle.php.json');

        // State management
        this.lastData = null;
        this.lastProcessedData = null;
        this.cachedData = this._generateClosedState();
        this.changeHistory = [];
        this.isPolling = false;
        this._activeRequests = new Set();
        this._pollInterval = null;
        this._backoffDelay = 0;

        // Dependencies
        this.statusProcessor = options.statusProcessor;
        this.changeDetector = options.changeDetector;
        this.metro = metro;
        this.timeAwaiter = new TimeAwaiter(this.metro);

        // Metrics
        this.metrics = {
            totalRequests: 0,
            failedRequests: 0,
            changeEvents: 0,
            lastSuccess: null,
            lastFailure: null,
            cacheHits: 0,
            avgResponseTime: 0,
            lastProcessingTime: 0,
            newsChecks: 0,
            newsPosted: 0
        };
        
        this.isFirstTime = true;

        // Public API
        this.api = Object.freeze({
            // Data access
            getRawData: () => this.lastData ? Object.freeze({...this.lastData}) : null,
            getProcessedData: this.getProcessedData.bind(this),
            getCachedData: () => Object.freeze({...this.cachedData}),
            
            // Status information
            status: this.getSystemStatus.bind(this),
            metrics: this.getMetrics.bind(this),
            
            // Change tracking
            changes: Object.freeze({
                history: this.getChangeHistory.bind(this),
                last: this.getLastChange.bind(this),
                stats: this.getChangeStats.bind(this),
                subscribe: (listener) => this.on(EventRegistry.CHANGES_DETECTED, listener),
                unsubscribe: (listener) => this.off(EventRegistry.CHANGES_DETECTED, listener)
            }),
            
            // Configuration
            reloadOverrides: async () => {
                const result = await this.override.loadOverrides();
                return { 
                    success: result, 
                    timestamp: new Date(),
                    overrides: this.override.getOverrides()
                };
            },
            
            // News service
            news: Object.freeze({
                check: this.checkNews.bind(this),
                forceCheck: async () => {
                    this.metrics.newsChecks++;
                    const result = await this.newsService.checkNews(true);
                    if (result?.posted) this.metrics.newsPosted += result.posted;
                    return result;
                },
                getPostedCount: () => this.metrics.newsPosted,
                getLastPosted: () => this.newsService.getLastPosted()
            }),
            
            // Control methods
            startPolling: this.startPolling.bind(this),
            stopPolling: this.stopPolling.bind(this),
            forceFetch: this.fetchNetworkStatus.bind(this),
            
            // Debugging
            debug: Object.freeze({
                simulateChange: this._simulateChange.bind(this),
                setChaosFactor: (factor) => {
                    this.chaosFactor = Math.max(0, Math.min(10000, factor));
                    return this.chaosFactor;
                },
                toggleDebug: (state) => {
                    this.debug = typeof state === 'boolean' ? state : !this.debug;
                    return this.debug;
                },
                injectNews: async (newsData) => {
                    return this.newsService.injectNews(newsData);
                },
                clearNewsCache: () => {
                    return this.newsService.clearCache();
                }
            })
        });
        
        logger.debug('[ApiService] Instance initialized');
    }

    async fetchNetworkStatus() {
        const requestId = crypto.randomUUID();
        logger.debug(`[ApiService] START fetch (ID: ${requestId.substr(0, 8)})`);
        this._activeRequests.add(requestId);
        this.metrics.totalRequests++;
        const startTime = performance.now();

        try {
            let rawData = this.timeHelpers.isWithinOperatingHours()
                ? await this._fetchWithRetry()
                : await this._readCachedData();

            if (!this.timeHelpers.isWithinOperatingHours()) {
                rawData = this._generateClosedState(rawData);
            }

            // Load and apply status overrides
            await this.override.loadOverrides();
            rawData = this.override.applyOverrides(rawData);

            if(!this.lastData) {
                this.lastData = rawData;
            }
            
            const randomizedData = this._randomizeStatuses(rawData);
            const changeResult = this.changeDetector.analyze(randomizedData, this.lastData);
            const processedData = this.statusProcessor
                ? this.statusProcessor.processRawAPIData(randomizedData)
                : this._basicProcessData(randomizedData);

            this.lastProcessedData = processedData;

            if (changeResult.changes?.length > 0) {
                if (!this.isFirstTime) {           
                    this.changeHistory.unshift(...changeResult.changes);
                    this.metrics.changeEvents += changeResult.changes.length;
                }
                
                this.isFirstTime = false;
                this._emitChanges(changeResult, processedData);
            }

            await this._storeProcessedData(processedData);
            this._updateState(processedData);

            // Check for news during operating hours
            if (this.timeHelpers.isWithinOperatingHours()) {
                this.metrics.newsChecks++;
                const newsResult = await this.newsService.checkNews();
                if (newsResult?.posted) {
                    this.metrics.newsPosted += newsResult.posted;
                }
            }

            this.lastData = rawData;
            this.timeAwaiter.checkTime();
            
            if (!this.timeHelpers.isWithinOperatingHours()) {
                this.metrics.cacheHits++;
                logger.debug('[ApiService] Used cached data (non-operating hours)');
            }

            return processedData;
        } catch (error) {
            console.error(`[ApiService] Fetch failed: ${error}`);
            this.metrics.failedRequests++;
            return this._fallbackToCachedData(error);
        } finally {
            const processingTime = performance.now() - startTime;
            this.metrics.avgResponseTime = 
                (this.metrics.avgResponseTime * (this.metrics.totalRequests - 1) + processingTime) / 
                this.metrics.totalRequests;
            this.metrics.lastProcessingTime = processingTime;
            
            this._activeRequests.delete(requestId);
            logger.debug(`[ApiService] END fetch (ID: ${requestId.substr(0, 8)})`);
        }
    }

    _generateClosedState(rawData = {}) {
        logger.debug('[ApiService] Generating closed state for non-operating hours');
        
        const state = rawData;
        
        Object.keys(state).forEach(lineId => {
            if (['l1', 'l2', 'l3', 'l4', 'l4a', 'l5', 'l6'].includes(lineId)) {
                if (state[lineId].estado !== undefined) state[lineId].estado = "0";
                if (state[lineId].mensaje !== undefined) state[lineId].mensaje = "Cierre por horario";
                if (state[lineId].mensaje_app !== undefined) state[lineId].mensaje_app = "Cierre por horario";
                
                if (Array.isArray(state[lineId].estaciones)) {
                    state[lineId].estaciones.forEach(station => {
                        if (station.estado !== undefined) station.estado = "0";
                        if (station.descripcion !== undefined) station.descripcion = "Cierre por horario";
                        if (station.descripcion_app !== undefined) station.descripcion_app = "Cierre por horario";
                    });
                }
            }
        });
        
        return state;
    }

    async _fetchWithRetry() {
        let lastError;
        const { maxRetries, baseRetryDelay, maxRetryDelay, timeout } = config.api;

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const response = await fetch(config.api.endpoint, {
                    headers: config.api.headers,
                    signal: AbortSignal.timeout(timeout)
                });

                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                
                const data = await response.json();
                this._validateApiResponse(data);
                return data;

            } catch (error) {
                lastError = error;
                
                if (attempt < maxRetries) {
                    const delay = this._calculateBackoff(attempt, baseRetryDelay, maxRetryDelay);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }

        throw lastError;
    }

    _calculateBackoff(attempt, baseDelay, maxDelay) {
        return Math.min(baseDelay * Math.pow(2, attempt - 1), maxDelay);
    }

    _validateApiResponse(data) {
        logger.debug('[ApiService] Validating response structure');
        if (!data || typeof data !== 'object') {
            throw new Error('Invalid network-status-json format');
        }
        
        Object.keys(data.lineas || {}).forEach(line => {
            if (!line.startsWith('l')) {
                throw new Error(`Invalid line ID format: ${line}`);
            }
        });
    }

    async _updateCache(data) {
        try {
            await fs.mkdir(this.cacheDir, { recursive: true });
            await fs.writeFile(this.cacheFile, JSON.stringify(data, null, 2));
            logger.debug('[ApiService] Cache updated successfully');
        } catch (error) {
            logger.error('[ApiService] Cache update failed', { error });
            throw error;
        }
    }

    async _readCachedData() {
        try {
            try {
                const data = await fs.readFile(this.cacheFile, 'utf8');
                return JSON.parse(data);
            } catch (newCacheError) {
                if (await this._fileExists(this.legacyCacheFile)) {
                    const legacyData = await fs.readFile(this.legacyCacheFile, 'utf8');
                    const parsedData = JSON.parse(legacyData);
                    await this._updateCache(parsedData);
                    return parsedData;
                }
                throw newCacheError;
            }
        } catch (error) {
            logger.error('[ApiService] Cache read failed', { error });
            throw error;
        }
    }

    async _fileExists(filePath) {
        try {
            await fs.access(filePath);
            return true;
        } catch {
            return false;
        }
    }

    _updateState(newData) {
        logger.debug('[ApiService] Updating service state');
        this.lastData = newData;
        this.cachedData = newData;
        this.metrics.lastSuccess = new Date();
        this._backoffDelay = 0;
        
        this.emit('data', newData);
        this._emitRawData(newData, false);
    }

    _randomizeStatuses(data) {
        if (!this.debug || !data) return data;
        
        this._cycleCount++;
        const prob = Math.max(0.1, 1 - (this.chaosFactor / 100));
        logger.debug(`[ApiService] Applying chaos (factor: ${this.chaosFactor}, prob: ${prob})`);

        Object.entries(data || {}).forEach(([lineId, line]) => {
            if (Math.random() < prob) {
                const newStatus = Math.floor(Math.random() * 4) + 1;
                logger.debug(`[ApiService] Changing ${lineId} to status ${newStatus}`);
                line.estado = newStatus.toString();
                line.mensaje = this._statusOptions.lineStatuses[newStatus].mensaje;
                line.mensaje_app = this._statusOptions.lineStatuses[newStatus].mensaje_app;
            }

            line.estaciones?.forEach(station => {
                if (Math.random() < prob * 0.7) {
                    const newStatus = Math.floor(Math.random() * 4) + 1;
                    station.estado = newStatus.toString();
                    station.descripcion = this._statusOptions.stationStatuses[newStatus].descripcion;
                    station.descripcion_app = this._statusOptions.stationStatuses[newStatus].descripcion_app;
                }
            });
        });

        return data;
    }

    _emitRawData(rawData, hasChanges) {
        const payload = new EventPayload(
            EventRegistry.RAW_DATA_FETCHED,
            Object.freeze({...rawData}),
            {
                source: 'ApiService',
                timestamp: new Date(),
                containsChanges: hasChanges
            }
        );

        this.emit(EventRegistry.RAW_DATA_FETCHED, payload);
    }

    _handleFetchError(error) {
        this._backoffDelay = this._calculateBackoff(
            this.metrics.failedRequests,
            config.api.maxRetryDelay || 30000
        );

        const payload = new EventPayload(
            EventRegistry.API_ERROR,
            {
                error: error.message,
                retryIn: this._backoffDelay,
                attempt: this.metrics.failedRequests
            },
            {
                source: 'ApiService',
                critical: this.metrics.failedRequests > 2
            }
        );

        this.emit(EventRegistry.API_ERROR, payload);
    }

    _emitChanges(changeResult, processedData) {
        if (!changeResult?.changes || changeResult.changes.length === 0) return;

        const changesArray = Array.isArray(changeResult.changes) 
            ? changeResult.changes 
            : [changeResult.changes].filter(Boolean);

        const validatedChanges = changesArray.map(change => {
            if (typeof change === 'string') {
                return {
                    id: change,
                    name: 'unknown', 
                    lineId: 'unknown', 
                    type: 'unknown',
                    from: 'unknown',
                    to: 'unknown',
                    severity: 'none'
                };
            }
            
            return {
                type: change.type,
                id: change.id || String(change.line || change.stationId || 'unknown'),
                name: change.name,
                line: change.line,
                from: String(change.from || change.fromState || 'unknown'),
                to: String(change.to || change.toState || 'unknown'),
                ...(change.description && { description: String(change.description) }),
                ...(change.timestamp && { timestamp: new Date(change.timestamp).toISOString() }),
                severity: ['critical','high','medium','low','none'].includes(change.severity) 
                    ? change.severity 
                    : 'none'
            };
        }).filter(change => change.id && change.type && change.from && change.to);

        const metadata = {
            severity: ['critical','high','medium','low','none'].includes(changeResult.severity)
                ? changeResult.severity
                : 'none',
            source: 'ApiService',
            timestamp: new Date().toISOString(),
            ...(Array.isArray(changeResult.groupedStations) && {
                groupedStations: changeResult.groupedStations
            })
        };

        const payload = new EventPayload(
            EventRegistry.CHANGES_DETECTED,
            {
                changes: validatedChanges,
                metadata: metadata,
                ...(this.lastProcessedData && { previousState: this.lastProcessedData }),
                ...(processedData && { newState: processedData })
            }
        );

        this.emit(EventRegistry.CHANGES_DETECTED, payload);
    }

    getChangeHistory() {
        return Object.freeze({
            entries: [...this.changeHistory],
            stats: this.getChangeStats()
        });
    }

    getChangeStats() {
        return Object.freeze({
            total: this.metrics.changeEvents,
            lastChange: this.changeHistory[0]?.timestamp || null,
            perHour: this._calculateChangesPerHour()
        });
    }

    getMetrics() {
        return Object.freeze({
            requests: {
                total: this.metrics.totalRequests,
                failed: this.metrics.failedRequests,
                successRate: this._calculateSuccessRate()
            },
            lastSuccess: this.metrics.lastSuccess,
            lastFailure: this.metrics.lastFailure,
            activeRequests: this._activeRequests.size,
            backoffDelay: this._backoffDelay,
            cacheHits: this.metrics.cacheHits,
            avgResponseTime: this.metrics.avgResponseTime,
            newsMetrics: {
                checks: this.metrics.newsChecks,
                posted: this.metrics.newsPosted,
                lastPosted: this.newsService.getLastPosted()
            }
        });
    }
    
    getLastChange() {
        return this.changeHistory[0] ? Object.freeze({...this.changeHistory[0]}) : null;
    }

    getSystemStatus() {
        return {
            isPolling: this.isPolling,
            lastUpdate: this.lastData?.timestamp || null,
            chaosFactor: this.chaosFactor,
            debugMode: this.debug,
            activeRequests: this._activeRequests.size,
            overridesActive: Object.values(this.override.getOverrides().lines).some(o => o.enabled) || 
                           Object.values(this.override.getOverrides().stations).some(o => o.enabled),
            newsService: this.newsService.getStatus()
        };
    }

    _calculateSuccessRate() {
        if (this.metrics.totalRequests === 0) return 0;
        return Math.round(
            ((this.metrics.totalRequests - this.metrics.failedRequests) / 
             this.metrics.totalRequests) * 100
        );
    }

    _calculateChangesPerHour() {
        if (this.changeHistory.length < 2) return 0;
        const first = new Date(this.changeHistory[0].timestamp);
        const last = new Date(this.changeHistory[this.changeHistory.length - 1].timestamp);
        const hours = (first - last) / (1000 * 60 * 60);
        return hours > 0 ? (this.changeHistory.length / hours).toFixed(2) : 0;
    }

    startPolling(interval = config.api.pollingInterval) {
        if (this.isPolling) return;

        interval = Math.max(60000, interval);
        logger.info(`[ApiService] Starting polling (${interval}ms)`);
        this.isPolling = true;
        this._pollInterval = setInterval(() => {
            this.fetchNetworkStatus()
                .catch(error => logger.error('[ApiService] Polling error:', error));
        }, interval);

        if (this._pollInterval.unref) {
            this._pollInterval.unref();
        }
    }

    stopPolling() {
        if (!this.isPolling) return;

        logger.info('[ApiService] Stopping polling');
        clearInterval(this._pollInterval);
        this._pollInterval = null;
        this.isPolling = false;
    }

    cleanup() {
        logger.info('[ApiService] Performing cleanup');
        this.stopPolling();
        this.removeAllListeners();
        this._activeRequests.clear();
        this.changeHistory = [];
        this.newsService.cleanup();
    }
    
    getProcessedData() {
        return this.lastProcessedData ? Object.freeze({...this.lastProcessedData}) : null;
    }
    
    async _storeProcessedData(data) {
        try {
            await fs.mkdir(this.cacheDir, { recursive: true });
            await fs.writeFile(
                this.processedDataFile,
                JSON.stringify(data, null, 2),
                'utf8'
            );
            logger.debug('[ApiService] Processed data stored successfully');
        } catch (error) {
            logger.error('[ApiService] Failed to store processed data', { error });
        }
    }

    async _fallbackToCachedData(error) {
        logger.warn('[ApiService] Falling back to cached data');
        try {
            const cachedData = await this._readCachedData();
            this.metrics.cacheHits++;
            this._updateState(cachedData);
            return cachedData;
        } catch (cacheError) {
            logger.error('[ApiService] Cache fallback failed', { error: cacheError });
            this.metrics.lastFailure = new Date();
            throw error;
        }
    }

    _basicProcessData(rawData) {
        return {
            network: {
                status: this.timeHelpers.isWithinOperatingHours() ? 'operational' : 'closed',
                timestamp: new Date().toISOString()
            },
            lines: Object.fromEntries(
                Object.entries(rawData.lineas || {})
                    .filter(([k]) => k.startsWith('l'))
                    .map(([lineId, lineData]) => [
                        lineId,
                        {
                            id: lineId,
                            status: lineData.estado,
                            message: lineData.mensaje,
                            message_app: lineData.mensaje_app,
                            stations: lineData.estaciones.map(station => ({
                                id: station.codigo,
                                name: station.nombre,
                                status: station.estado,
                                description: station.descripcion,
                                description_app: station.descripcion_app,
                                transfer: station.combinacion || '',
                                ...(station.isTransferOperational !== undefined && { 
                                    isTransferOperational: station.isTransferOperational 
                                }),
                                ...(station.accessPointsOperational !== undefined && { 
                                    accessPointsOperational: station.accessPointsOperational 
                                })
                            }))
                        }
                    ])
            ),
            version: Date.now().toString(),
            lastUpdated: new Date().toISOString()
        };
    }

    async checkNews() {
        this.metrics.newsChecks++;
        try {
            const result = await this.newsService.checkNews();
            if (result?.posted) {
                this.metrics.newsPosted += result.posted;
            }
            return { 
                success: true, 
                posted: result?.posted || 0,
                timestamp: new Date() 
            };
        } catch (error) {
            logger.error('[ApiService] News check failed:', error);
            return { success: false, error: error.message };
        }
    }

    _simulateChange(type, data) {
        logger.warn('[ApiService] Simulating change event');
        const simulatedChange = {
            type: type || 'simulated',
            id: data?.id || 'simulated_' + Date.now(),
            from: data?.from || '1',
            to: data?.to || '2',
            timestamp: new Date().toISOString(),
            severity: data?.severity || 'medium'
        };
        
        this._emitChanges({
            changes: [simulatedChange],
            severity: simulatedChange.severity
        }, this.lastProcessedData);
        
        return simulatedChange;
    }
}

module.exports = ApiService;
