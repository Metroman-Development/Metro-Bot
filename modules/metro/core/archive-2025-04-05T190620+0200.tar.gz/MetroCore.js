// Add these at the top of MetroCore.js with other imports
const  ScheduleManager = require('../../chronos/managers/ScheduleManager');
const EventManager = require('../../chronos/managers/EventManager');
const Logger = require('../../chronos/utilities/Logger'); 
   
const schedule = require('node-schedule');                      // For job scheduling
const moment = require('moment-timezone');                      // For timezone handling
const chronosConfig = require('../../../config/chronosConfig');    // For schedule configs
// Core modules
const EventEmitter = require('events');
const path = require('path');

// Subsystems
const DataLoader = require('./DataLoader');
const ApiService = require('./services/ApiService');
const StationManager = require('./managers/StationManager');
const LineManager = require('./managers/LineManager');

// Utilities
const stringUtils = require('../utils/stringHandlers');
const config = require('../../../config/metro/metroConfig');
const styles = require('../../../config/metro/styles.json');

// Status system
const StatusProcessor = require('../../status/utils/StatusProcessor');
const ChangeDetector = require('../../status/ChangeDetector');
const ChangeAnnouncer = require('../../status/ChangeAnnouncer');
const StatusService = require('../../status/StatusService');
const StatusUpdater = require('../../status/embeds/StatusUpdater'); 

// Logging
const logger = require('../../../events/logger');

// modules/metro/core/MetroCore.js


class MetroCore extends EventEmitter {
    
    
  static #instance = null;
 
  static #initializationPromise = null;

  constructor(options = {}) {
      
      console.log("👉👉❤️👉❤️🤣❤️❤️😅❤️");

    if (MetroCore.#instance) {

      return MetroCore.#instance;

    }

    super();

    MetroCore.#instance = this;

    this._debug = options.debug || false;

    this.client = options.client || null;

    this.config = options.config || require('../../../config/metro/metroConfig');

    this.styles = options.styles || require('../../../config/metro/styles.json');

    // Core Data Structures

    this._staticData = null;

    this._dynamicData = null;

    this._combinedData = null;

    this._dataVersion = null;

    this._pollingInterval = null;

    // Subsystems (maintaining original structure)

    this._subsystems = {
        
      api: new ApiService(),

      dataLoader: new DataLoader(),
        
      scheduleHelpers: require('../../chronos/utils/scheduleHelpers'), 


      statusProcessor: new StatusProcessor(this),

      changeDetector: new ChangeDetector(),

      statusService: new StatusService(this),
        
      statusUpdater: null, 
        
                                      
                                    

        
       
     changeAnnouncer: new ChangeAnnouncer(), 

      managers: {

        stations: null,

        lines: null

      },

      utils: {

        string: stringUtils,

        config: this.config

      }

    };

    

   
      
    console.log('[MetroCore] Instance created');
      
    //console.log(DataLoader);

  }
  static getInstance = async (options = {}) => {
      
   const util = require('util');

console.log(util.inspect(this._subsystems, {

  depth: 3,          // How deep to traverse

  showHidden: true,  // Show non-enumerable props (like Symbols)

  colors: true       // Colorize output

}));
        
    if (this.#instance) return this.#instance;

    if (this.#initializationPromise) return this.#initializationPromise;

    

    this.#initializationPromise = (async () => {

      const instance = new MetroCore(options);

      await instance.initialize();

      /* if(!this._staticData){

        

        this._staticData = await this._subsystems.dataLoader.load();

        

        }*/  
        
      return instance;

    })();

    return this.#initializationPromise;
      
    

  }

  // In MetroCore.js - updated initialize() method



    async initialize() {
        try {
            
            console.log(this._subsystems.changeAnnouncer);
            logger.debug('[MetroCore] Starting initialization');

            // 1. Immediate event pipeline setup
            this._setupEventPipeline();

            // 2. Initialize scheduling system EARLY (modified)
            await this._initializeSchedulingSystem(); // Now async
            
            // 3. Load static data 
            this._staticData = await this._subsystems.dataLoader.load();
            this._dataVersion = this._staticData.version || Date.now();
            logger.debug('🚇🚇🚉🚉🚇[MetroCore] Static data loaded');

            // 4. Initialize managers with data
            this._subsystems.managers.stations = new StationManager(
                this._createStationInterface(this._staticData.stations || {}),
                this._subsystems.utils
            );

            this._subsystems.managers.lines = new LineManager(
                this._createLineInterface(this._staticData.lines || {}),
                this._subsystems.utils
            );

            // 5. Start polling after data is ready
            await this._subsystems.api.fetchNetworkStatus();
            this.startPolling();

            // 6. Initialize StatusUpdater
            this._subsystems.statusUpdater = new StatusUpdater(this);
            await this._subsystems.statusUpdater.initialize();

            logger.debug('[MetroCore] Initialization complete');
            this.emit('ready');
        } catch (error) {
            logger.error('[MetroCore] Initialization failed:', error);
            this.emit('error', error);
            throw error;
        }
        
        
await this.sendFullStatusReport();
    }

    async _initializeSchedulingSystem() {
    try {
        if (!this.client) throw new Error("Client not available");
        if (!chronosConfig.timezone) throw new Error("Timezone not configured");

        // Initialize scheduler with proper error handling
        this._scheduler = new ScheduleManager(this.client);
        if (!(this._scheduler instanceof EventEmitter)) {
            throw new Error("ScheduleManager is not an EventEmitter");
        }

        // Initialize event manager
        this._eventManager = new EventManager(this.client);

        // Create a promise that resolves when scheduler is ready
        const schedulerReady = new Promise((resolve, reject) => {
            this._scheduler.once('ready', resolve);
            this._scheduler.once('error', reject);
        });

        // Start initialization
        const initPromise = this._scheduler.initialize();

        // Wait for both initialization and ready event
        await Promise.all([initPromise, schedulerReady]);

        // Initialize event manager
        await this._eventManager.loadAndScheduleEvents();

        // Set up event forwarding
        this._setupSchedulerEvents();

        logger.debug('[MetroCore] Scheduling system ready');
    } catch (error) {
        logger.error('[MetroCore] Scheduler setup failed:', {
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
        
        
}


    // Replace _setupScheduledEmissions() with this:
_setupSchedulerEvents() {
    const helpers = this._subsystems.utils.scheduleHelpers;

    // Service Hours Emissions
    this._scheduler.on('serviceTransition', (data) => {
        this.emit('serviceChange', {
            ...data,
            systemState: {
                period: helpers.getCurrentPeriod(),
                dayType: helpers.getCurrentDayType(),
                isExpressActive: helpers.shouldRunExpress(),
                isServiceHour: helpers.isServiceHour(),
                nextTransition: helpers.getUpcomingTransitions()[0] || null
            },
            timestamp: moment().tz(chronosConfig.timezone).format()
        });
    });

    // Express Service Emissions
    this._scheduler.on('expressServiceChange', (data) => {
        this.emit('expressServiceUpdate', {
            ...data,
            context: {
                nextWindow: helpers.getNextExpressWindow(),
                affectedLines: this._subsystems.config.expressLines,
                currentLoad: this._calculateCurrentLoad()
            },
            timestamp: moment().tz(chronosConfig.timezone).format()
        });
    });
}

   _calculateCurrentLoad() {
    const helpers = this._subsystems.utils.scheduleHelpers;
    const period = helpers.getCurrentPeriod();
    
    return {
        period,
        severity: period === 'PUNTA' ? 'high' : 
                 period === 'VALLE' ? 'normal' : 'low',
        activeStations: this.stations.getAll()
            .filter(s => s.status.code === 1).length,
        delayedTrains: this.lines.getAll()
            .filter(l => l.status.code === 4).length || 0
    };
}
    

// Add these to the MetroCore class exports if they don't exist
get scheduler() {
  return this._scheduler;
}
  // In MetroCore.js - modify _setupEventPipeline
_setupEventPipeline() {
  // API → StatusProcessor → ChangeDetector
  this._subsystems.api.on('rawDataFetched', (rawData) => {
    try {
      const processed = this._subsystems.statusProcessor.processRawAPIData(rawData);
      const previousState = this._dynamicData;
      this._dynamicData = processed;
      
      // Analyze changes with the detector
      const changes = this._subsystems.changeDetector.analyze(processed, previousState);
      
      this._combineData();
        
      //console.log(processed)
        
    } catch (error) {
      logger.error('[MetroCore] Data processing failed:', error);
      this.emit('processingError', error);
    }
  });

  // ChangeDetector → ChangeAnnouncer → StatusService
  this._subsystems.changeDetector.on('changes', (changes) => {
    const announcements = this._subsystems.changeAnnouncer.generateMessages(changes);
    this._subsystems.statusService.handleAnnouncements(announcements, changes);
  });

  // StatusService → MetroCore
  this._subsystems.statusService.on('statusUpdated', (newStatus) => {
    this._updateSystemState(newStatus);
  });
}

  _combineData() {
      
      console.log('[MetroCore] Combining static and dynamic data');

   //console.log(this._staticData)
     
   if (!this._staticData) {
       console.log("S doesn't exist");
      }

          

   if (!this._dynamicData) {
       console.log("D doesn't exist");

       }
      
      console.log("[MC] Combining data");
   

    // Combined data structure

    this._combinedData = {

      version: this._dataVersion,

      lastUpdated: new Date(),

      lines: this._enrichLines(),
        
      

      stations: this._enrichStations(),

      network: this._dynamicData.network

    };

    // Update managers with new data


      console.log("[MC] Updating Data");
      this._subsystems.managers.stations.updateData(

      this._createStationInterface(this._combinedData.stations)

    );

    this._subsystems.managers.lines.updateData(

      this._createLineInterface(this._combinedData.lines)

    );

    logger.debug('[MetroCore] Data combination complete');
      
      //console.log(this._staticData) ;   

    this.emit('dataUpdated', this._combinedData);

  }
  
   _enrichLines() {

    console.log("[MC] Enriching Lines with Combined Data");

    

    try {

        // Validate data sources

        if (!this._dynamicData?.lines || !this._staticData?.lines) {

            throw new Error('Missing required line data sources');

        }

        return Object.entries(this._dynamicData.lines).reduce((acc, [lineId, dynamicLine]) => {

            if (!dynamicLine || typeof dynamicLine !== 'object') {

                console.warn(`[MC] Skipping invalid dynamic line: ${lineId}`);

                return acc;

            }

            const staticLine = this._staticData.lines[lineId] || {};

            const normalizedStatus = dynamicLine.normalizedStatus || 

                                  normalizeStatus(dynamicLine.status?.code || '1');

            // Merged line object

            const enrichedLine = {

                // Core identifiers

                id: lineId,

                systemId: staticLine.systemId || `metro-${lineId}`,

                

                // Presentation

                displayName: dynamicLine.displayName || staticLine.displayName || `Línea ${lineId.toUpperCase()}`,

                color: dynamicLine.color || staticLine.color || 

                     this.styles?.lineColors?.[lineId] || this.config?.defaultLineColor || '#CCCCCC',

                

                // Status information

                status: {

                    ...(dynamicLine.status || {}),

                    code: dynamicLine.status?.code || staticLine.status?.code || '1',

                    message: dynamicLine.status?.message || staticLine.status?.message || '',

                    appMessage: dynamicLine.status?.appMessage || staticLine.status?.appMessage || ''

                },

                normalizedStatus,

                operationalStatus: normalizedStatus,

                

                // Combined details

                details: {

                    ...(staticLine.details || {}),

                    length: staticLine.details?.length || 0,

                    stations: staticLine.details?.stationCount || 0,

                    inauguration: staticLine.details?.inauguration || 'Unknown',

                    communes: Array.isArray(staticLine.details?.communes) ? 

                            staticLine.details.communes : []

                },

                

                // Fleet data (static overrides dynamic)

                fleet: Array.isArray(staticLine.fleet) ? 

                     staticLine.fleet : 

                     (Array.isArray(dynamicLine.fleet)) ? dynamicLine.fleet : [],

                

                // Infrastructure (dynamic with static fallback)

                infrastructure: {

                    ...(dynamicLine.infrastructure || {}),

                    operationalStatus: normalizedStatus,

                    lastUpdated: new Date(),

                    stationCodes: Array.isArray(dynamicLine.stations) ? 

                               dynamicLine.stations : 

                               (Array.isArray(staticLine.stations) ? staticLine.stations : [])

                },

                

                // Stations reference

                stations: Array.isArray(dynamicLine.stations) ? 

                        dynamicLine.stations : []

            };

            // Validation

            if (!enrichedLine.id || !enrichedLine.displayName) {

                console.warn(`[MC] Incomplete enrichment for line ${lineId}`);

            }

            acc[lineId] = enrichedLine;

            return acc;

        }, {});

    } catch (error) {

        console.error("[MC] Line enrichment failed:", error);

        return this._getBasicLinesStructure();

    }

}

// Add to MetroCore class

getCurrentData() {

    return this._combinedData;

}

_getBasicLinesStructure() {

    return Object.keys(this._dynamicData?.lines || {}).reduce((acc, lineId) => {

        acc[lineId] = {

            id: lineId,

            displayName: `Línea ${lineId.toUpperCase()}`,

            color: this.styles?.lineColors?.[lineId] || '#CCCCCC',

            status: { code: '1', message: 'Operational' },

            normalizedStatus: 'operational',

            stations: []

        };

        return acc;

    }, {});

} 

  _enrichStations() {


     console.log("enrichingstations") 
      
     const product = Object.entries(this._dynamicData.stations).reduce((acc, [stationId, station]) => {

      const staticStation = this._staticData.stations[stationId] || {};

      acc[stationId] = {

        ...station,

        displayName: station.name,

        color: this.styles.lineColors[station.line] || this.config.defaultLineColor,

        combination: staticStation.combination || null,

        amenities: staticStation.amenities || [],

        accessibility: staticStation.accessibility || {},

        location: staticStation.location || null,

        commune: staticStation.commune || 'Unknown'

      };

      return acc;

    }, {});

      console.log("enrichingstations success") 
      
    return product
  }

  _createStationInterface(stationsData) {

    const self = this;

    return {

      getAll: () => Object.values(stationsData),

      get: (id) => stationsData[id],

      setStatus: function(id, status) {

        if (stationsData[id]) {

          stationsData[id].status = status;

          self._subsystems.statusService._handleStationChange(id, status);

          return true;

        }

        return false;

      },

      count: () => Object.keys(stationsData).length,

      search: (query) => {

        const normalizedQuery = query.toLowerCase();

        return Object.values(stationsData).filter(station => 

          station.name.toLowerCase().includes(normalizedQuery)

    ) }

    };

  }

  _createLineInterface(linesData) {

    const self = this;

    return {

      getAll: () => Object.values(linesData),

      get: (id) => linesData[id.toLowerCase()],

      setStatus: function(id, status) {

        const line = linesData[id.toLowerCase()];

        if (line) {

          line.status = status;

          self._subsystems.statusService._handleLineChange(id, status);

          return true;

        }

        return false;

      },

      addStation: (lineId, station) => {

        const line = linesData[lineId.toLowerCase()];

        if (line) {

          if (!line.stations) line.stations = [];

          line.stations.push(station);

          return true;

        }

        return false;

      },

      getStations: (lineId) => {

        const line = linesData[lineId.toLowerCase()];

        return line?.stations || [];

      }

    };

  }

  _updateSystemState(newStatus) {

    logger.debug('[MetroCore] Updating system state');

    

    // Update status in combined data

    if (newStatus.lines) {

      Object.entries(newStatus.lines).forEach(([lineId, status]) => {

        if (this._combinedData.lines[lineId]) {

          this._combinedData.lines[lineId].status = status;

        }

      });

    }

    if (newStatus.stations) {

      Object.entries(newStatus.stations).forEach(([stationId, status]) => {

        if (this._combinedData.stations[stationId]) {

          this._combinedData.stations[stationId].status = status;

        }

      });

    }

    // Update network status

    this._combinedData.network = this._subsystems.statusService.getNetworkStatus();

    this._combinedData.lastUpdated = new Date();

    this.emit('systemUpdate', this._combinedData);

  }

  startPolling(interval = 60000) {

    if (this._pollingInterval) clearInterval(this._pollingInterval);

    

    logger.info(`[MetroCore] Starting polling every ${interval}ms`);

    this._pollingInterval = setInterval(() => {

      this._subsystems.api.fetchNetworkStatus().catch(error => {

        logger.error('[MetroCore] Polling error:', error);

      });

    }, interval);

    // Initial fetch

    this._subsystems.api.fetchNetworkStatus();

  }

  // Public API

  getSystemStatus() {

    return {

      version: this._dataVersion,

      status: this._combinedData.network,

      lastUpdated: this._combinedData.lastUpdated,

      lines: {

        total: Object.keys(this._combinedData.lines).length,

        operational: Object.values(this._combinedData.lines)

          .filter(line => line.status.code === '1').length

      },

      stations: {

        total: Object.keys(this._combinedData.stations).length,

        operational: Object.values(this._combinedData.stations)

          .filter(station => station.status.code === '1').length

      }

    };

  }

  get dataVersion() {

    return this._dataVersion;

  }

  get stations() {

    return {

      get: (id) => {

        const station = this._subsystems.managers.stations.get(id);

        return station ? { 

          ...station,

          status: this._subsystems.statusService.getStationStatus(id)

        } : null;

      },

      getAll: () => this._subsystems.managers.stations.getAll().map(s => ({

        ...s,

        status: this._subsystems.statusService.getStationStatus(s.id)

      })),

      search: (query) => this._subsystems.managers.stations.search(query),

      count: () => this._subsystems.managers.stations.count()

    };

  }

  get lines() {

    return {

      get: (id) => {

        const line = this._subsystems.managers.lines.get(id);

        return line ? {

          ...line,

          status: this._subsystems.statusService.getLineStatus(id)

        } : null;

      },

      getAll: () => this._subsystems.managers.lines.getAll().map(l => ({

        ...l,

        status: this._subsystems.statusService.getLineStatus(l.id)

      })),

      getStations: (lineId) => 

        this._subsystems.managers.lines.getStations(lineId).map(s => 

          this.stations.get(s))

    };

  }

  get utils() {

    return this._subsystems.utils;

  }

  // Forced status management

  forceLineStatus(lineId, status) {

    this._subsystems.statusService.forceLineStatus(lineId, status);

  }

  clearForcedStatus(lineId) {

    this._subsystems.statusService.clearForcedStatus(lineId);

  }

  // Debug methods

  _getInternalState() {

    return {

      dataVersion: this._dataVersion,

      staticData: this._staticData,

      dynamicData: this._dynamicData,

      combinedData: this._combinedData,

      subsystems: {

        stations: this._subsystems.managers.stations?._getInternalState?.(),

        lines: this._subsystems.managers.lines?._getInternalState?.()

      }

    };

  }

// ... (Previous MetroCore.js code remains exactly the same until the end of the class) ...

  // Add this new method to the MetroCore class
  async sendFullStatusReport() {
    try {
      
        console.log("⚠️ Building Status Report")
        
      const currentData = this._combinedData || await this.getSystemStatus();
      const statusService = this._subsystems.statusService;
      const helpers = this._subsystems.utils.scheduleHelpers;
      
      // Calculate metrics
      const operationalLines = Object.values(currentData.lines)
        .filter(line => line.status.code === '1').length;
      const problematicStations = Object.values(currentData.stations)
        .filter(station => station.status.code !== '1').length;
      
      // Create embed
      const statusEmbed = {
        title: '🚇 Metro System Status Report',
        description: `Comprehensive operational status as of ${new Date().toLocaleString()}`,
        color: 0x009688, // Teal color
        timestamp: new Date().toISOString(),
        fields: [
          {
            name: '📊 Network Overview',
            value: [
              `**Status:** ${currentData.network.operational ? '✅ Operational' : '❌ Disrupted'}`,
              `**Lines:** ${operationalLines}/${Object.keys(currentData.lines).length} fully operational`,
              `**Stations:** ${problematicStations} with issues`,
              `**Last Update:** ${currentData.lastUpdated.toLocaleTimeString()}`
            ].join('\n'),
            inline: true
          },
          {
            name: '⏰ Current Schedule',
            value: [
              `**Period:** ${helpers?.getCurrentPeriod() || "Error al Obtener la Información"}`,
              `**Day Type:** ${helpers?.getCurrentDayType() || "Error al Obtener la Información"}`,
              `**Express Active:** ${(helpers?.shouldRunExpress() ? 'Yes' : 'No')  || "Error al Obtener la Información"}`,
              `**Next Transition:** ${helpers?.getUpcomingTransitions()[0]?.type || 'None'} at ${helpers?.getUpcomingTransitions()[0]?.time || 'N/A'}`
            ].join('\n'),
            inline: true
          },
          {
            name: '🔄 System Info',
            value: [
              `**Data Version:** ${this._dataVersion}`,
              `**Polling:** ${this._pollingInterval ? 'Active' : 'Inactive'}`,
              `**Debug Mode:** ${this._debug ? 'On' : 'Off'}`,
              `**Uptime:** ${process.uptime().toFixed(1)} seconds`
            ].join('\n'),
            inline: true
          }
        ],
        footer: {
          text: 'Metro Core Monitoring System',
          icon_url: 'https://cdn.discordapp.com/attachments/1326594661003034635/135259880988161842/logo_metro_versiones-04.jpg'
        }
      };

      // Add line-by-line status
      const lineStatuses = Object.entries(currentData.lines).map(([id, line]) => {
        return {
          name: `Line ${id.toUpperCase()} ${line.status.code === '1' ? '✅' : '⚠️'}`,
          value: `**Status:** ${line.status.message || 'No status'}\n` +
                 `**Stations:** ${line.stations.length}\n` +
                 `**Last Issue:** ${line.status.lastIncident || 'None'}`,
          inline: true
        };
      });
      
      statusEmbed.fields.push(...lineStatuses);

      // Add subsystem status
      statusEmbed.fields.push({
        name: '⚙️ Subsystem Status',
        value: [
          `**API:** ${this._subsystems.api.lastData ? 'Connected' : 'Disconnected'}`,
          `**Database:** ${this._subsystems.dataLoader.ready ? 'Ready' : 'Loading'}`,
          `**Scheduler:** ${this._scheduler ? 'Active' : 'Inactive'}`,
          `**Change Detection:** ${this._subsystems.changeDetector.consecutiveNoChangeCount} no changes cycles`
        ].join('\n')
      });

      // Send to Discord (assuming this.client is your Discord client)
      if (this.client) {
        const channel = await this.client.channels.fetch('1350243847271092295');
        if (channel) {
          await channel.send({
            embeds: [statusEmbed],
            content: `**Metro System Status Update**`
          });
          logger.debug('[MetroCore] Status report sent successfully');
        } else {
          logger.error('[MetroCore] Status report channel not found');
        }
      }

      return statusEmbed;
    } catch (error) {
      logger.error('[MetroCore] Failed to generate status report:', error);
      throw error;
    }
  }
}

module.exports = MetroCore;
