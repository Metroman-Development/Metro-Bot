// File: RoutePlanner.js
// File: RoutePlanner.js
const logger = require('../../events/logger');
const config = require('../../config/metro/metroConfig');

class RoutePlanner {
    static async getRoutes(startCode, endCode, farePeriod) {
        try {
            
            console.log(startCode)

            console.log(endCode)
            
            const apiUrl = `https://www.metro.cl/api/planificadorv2.php?estacionInicio=${startCode.toUpperCase()}&estacionFin=${endCode.toUpperCase()}&dia=dl&hora=${farePeriod.toUpperCase()}`;
            const response = await fetch(apiUrl);
            
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            const data = await response.json();
            if (data.estado !== 1 || !data.rutas?.length) return null;

            return this._processRoutes(data.rutas, farePeriod);
        } catch (error) {
            logger.error(`RoutePlanner Error: ${error}`);
            return null;
        }
    }

    static _processRoutes(routes, farePeriod) {
        return routes
            .sort((a, b) => a.tiempo - b.tiempo)
            .map(route => ({
                id: this._generateRouteId(route),
                totalTime: route.tiempo,
                stationCount: route.estaciones,
                segments: this._processSegments(route.tramos),
                transferCount: route.tramos.filter(t => t.tipo === 'combinacion').length,
                farePeriod: farePeriod,
                rawData: route // Keep original data for reference
            }));
    }

    static _processSegments(tramos) {
        return tramos.map(tramo => {
            const baseSegment = {
                type: tramo.tipo,
                duration: this._parseDuration(tramo.tiempo),
                direction: tramo.direccion
            };

            if (tramo.tipo === 'combinacion') {
                return {
                    ...baseSegment,
                    transferLine: tramo.linea?.toUpperCase() || 'UNKNOWN',
                    transferStation: tramo.direccion
                };
            }

            return {
                ...baseSegment,
                from: this._processStation(tramo.inicio),
                to: this._processStation(tramo.fin)
            };
        });
    }

    static _processStation(stationData) {
        return {
            code: stationData.sigla,
            name: stationData.nombre,
            line: stationData.linea?.toUpperCase() || 'UNKNOWN',
            accessibility: this._cleanAccessibility(stationData.accesibilidad)
        };
    }

    static _parseDuration(durationStr) {
        if (typeof durationStr === 'number') return durationStr;
        const match = durationStr.match(/(\d+)\s*minutos?/);
        return match ? parseInt(match[1]) : 0;
    }

    static _cleanAccessibility(html) {
        if (!html) return null;
        return html
            .replace(/<[^>]*>/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    static _generateRouteId(route) {
        const firstStation = route.tramos[0]?.inicio?.sigla || 'start';
        const lastStation = route.tramos[route.tramos.length - 1]?.fin?.sigla || 'end';
        return `${firstStation}-${lastStation}-${Date.now().toString(36)}`;
    }
}

module.exports = RoutePlanner;