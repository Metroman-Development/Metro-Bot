const moment = require('moment-timezone');
const config = require('./config/statusConfig');
const logger = require('../../events/logger');

class ChangeDetector {
    constructor(metro) {
        if (!metro?.core) {
            throw new Error('ChangeDetector requires initialized Metro instance with core');
        }

        this.metro = metro;
        this.stateHistory = [];
        this.statusSummary = {
            lastChange: null,
            currentStatus: 'initializing',
            activeEvents: [],
            forcedStatuses: new Map(),
            changeFrequency: 'N/A'
        };
        this.MAX_HISTORY = 100;
    }

    /**
     * Analyzes changes between current and previous states
     * @returns {object} Change analysis results
     */
    analyzeChanges() {
        const now = moment().tz(config.TIMEZONE);
        const currentData = this.metro.core.data;
        const previousState = this.stateHistory[0] || null;

        const processedData = this.applyStatusOverrides(currentData, now);
        const changes = {
            timestamp: now,
            network: this.detectNetworkChange(previousState, processedData),
            lines: this.detectLineChanges(previousState, processedData),
            stations: this.detectStationChanges(previousState, processedData),
            events: this.detectEventChanges(now),
            anomalies: this.detectAnomalies(processedData)
        };

        this.updateStatusSummary(changes, now);
        this.storeState(processedData);
        
        return {
            hasChanges: this.hasMeaningfulChanges(changes),
            summary: this.statusSummary,
            details: changes
        };
    }

    /**
     * Applies schedule-based status overrides
     * @param {object} data - Raw metro data 
     * @param {moment} now - Current time
     * @returns {object} Processed data with overrides
     */
    applyStatusOverrides(data, now) {
        const processed = JSON.parse(JSON.stringify(data));
        const isOperatingHours = config.isServiceHours(now);
        const activeEvent = config.getActiveEvent(now);

        // 1. Event active + outside normal hours
        if (activeEvent && !isOperatingHours) {
            this.overrideEventStations(processed, activeEvent, 5); // Extended status
        } 
        // 2. Outside hours + no event
        else if (!isOperatingHours) {
            this.overrideAllStations(processed, 0); // Overnight status
        }
        // 3. Event active + normal hours
        else if (activeEvent) {
            this.overrideNonEventStations(processed, activeEvent, 1); // Normal hours
        }

        return processed;
    }

    /**
     * Overrides status for event-affected stations
     * @param {object} data - Metro data
     * @param {object} event - Active event
     * @param {number} statusCode - Status code to apply
     */
    overrideEventStations(data, event, statusCode) {
        event.affectedStations.forEach(stationId => {
            for (const line in data) {
                data[line].stations.forEach(station => {
                    if (station.code === stationId) {
                        station.status = statusCode.toString();
                        station.description = `Horario extendido por ${event.name}`;
                    }
                });
            }
        });
    }

    /**
     * Overrides status for all stations
     * @param {object} data - Metro data 
     * @param {number} statusCode - Status code to apply
     */
    overrideAllStations(data, statusCode) {
        for (const line in data) {
            data[line].status = statusCode.toString();
            data[line].stations.forEach(station => {
                station.status = statusCode.toString();
                station.description = 'Cerrado por horario';
            });
        }
    }

    /**
     * Overrides status for non-event stations
     * @param {object} data - Metro data
     * @param {object} event - Active event 
     * @param {number} statusCode - Status code to apply
     */
    overrideNonEventStations(data, event, statusCode) {
        const affectedStations = new Set(event.affectedStations);
        for (const line in data) {
            data[line].stations.forEach(station => {
                if (!affectedStations.has(station.code)) {
                    station.status = statusCode.toString();
                    station.description = 'Operación normal';
                }
            });
        }
    }

    /**
     * Detects network-level changes
     * @param {object|null} oldState - Previous state
     * @param {object} newState - Current state
     * @returns {object} Change analysis
     */
    detectNetworkChange(oldState, newState) {
        if (!oldState) return { statusChanged: false };
        
        const oldStatus = this.calculateNetworkStatus(oldState);
        const newStatus = this.calculateNetworkStatus(newState);
        
        return {
            statusChanged: oldStatus !== newStatus,
            oldStatus,
            newStatus
        };
    }

    /**
     * Calculates overall network status
     * @param {object} data - Metro data
     * @returns {string} Status key
     */
    calculateNetworkStatus(data) {
        const statusCounts = {};
        for (const line in data) {
            const status = data[line].status;
            statusCounts[status] = (statusCounts[status] || 0) + 1;
        }

        if (statusCounts['2'] > 0) return 'major_outage';
        if (statusCounts['3'] > 0) return 'partial_outage';
        if (statusCounts['4'] > 0) return 'delayed';
        return 'operational';
    }

    /**
     * Detects line-level changes
     * @param {object|null} oldState - Previous state
     * @param {object} newState - Current state
     * @returns {object} Changed lines
     */
    detectLineChanges(oldState, newState) {
        if (!oldState) return { changedLines: [] };

        const changes = [];
        for (const lineId in newState) {
            const oldLine = oldState[lineId];
            const newLine = newState[lineId];

            if (!oldLine || oldLine.status !== newLine.status) {
                changes.push({
                    lineId,
                    oldStatus: oldLine?.status || 'unknown',
                    newStatus: newLine.status
                });
            }
        }

        return { changedLines: changes };
    }

    /**
     * Detects station-level changes
     * @param {object|null} oldState - Previous state 
     * @param {object} newState - Current state
     * @returns {object} Changed stations
     */
    detectStationChanges(oldState, newState) {
        if (!oldState) return { changedStations: [] };

        const changes = [];
        for (const lineId in newState) {
            const newStations = newState[lineId].stations;
            const oldStations = oldState[lineId]?.stations || [];

            newStations.forEach((newStation, index) => {
                const oldStation = oldStations[index];
                if (!oldStation || oldStation.status !== newStation.status) {
                    changes.push({
                        lineId,
                        stationId: newStation.code,
                        oldStatus: oldStation?.status || 'unknown',
                        newStatus: newStation.status
                    });
                }
            });
        }

        return { changedStations: changes };
    }

    /**
     * Detects active event changes
     * @param {moment} now - Current time
     * @returns {object} Event changes
     */
    detectEventChanges(now) {
        const activeEvents = config.getActiveEvent(now) ? 
            [config.getActiveEvent(now)] : [];
        
        return {
            activeEvents,
            changes: this.compareEvents(this.statusSummary.activeEvents, activeEvents)
        };
    }

    /**
     * Compares previous and current events
     * @param {array} previousEvents 
     * @param {array} currentEvents
     * @returns {object} Started/ended events
     */
    compareEvents(previousEvents, currentEvents) {
        const previousIds = new Set(previousEvents.map(e => e.id));
        const currentIds = new Set(currentEvents.map(e => e.id));

        return {
            started: currentEvents.filter(e => !previousIds.has(e.id)),
            ended: previousEvents.filter(e => !currentIds.has(e.id))
        };
    }

    /**
     * Detects data anomalies
     * @param {object} data - Metro data
     * @returns {array} Anomalies found
     */
    detectAnomalies(data) {
        const anomalies = [];
        
        // Detect lines with no operational stations
        for (const lineId in data) {
            const operationalStations = data[lineId].stations.filter(
                s => s.status === '1'
            ).length;
            
            if (operationalStations === 0) {
                anomalies.push({
                    type: 'line_outage',
                    lineId,
                    severity: 'critical'
                });
            }
        }

        return anomalies;
    }

    /**
     * Determines if changes are meaningful
     * @param {object} changes - Detected changes
     * @returns {boolean} True if meaningful changes exist
     */
    hasMeaningfulChanges(changes) {
        return changes.network.statusChanged ||
               changes.lines.changedLines.length > 0 ||
               changes.stations.changedStations.length > 0 ||
               changes.events.changes.started.length > 0 ||
               changes.events.changes.ended.length > 0 ||
               changes.anomalies.length > 0;
    }

    /**
     * Updates status summary
     * @param {object} changes - Detected changes
     * @param {moment} timestamp - Change time
     */
    updateStatusSummary(changes, timestamp) {
        this.statusSummary.lastChange = timestamp;
        this.statusSummary.currentStatus = this.calculateNetworkStatus(this.metro.core.data);
        this.statusSummary.activeEvents = changes.events.activeEvents;
        this.statusSummary.changeFrequency = this.calculateChangeFrequency(timestamp);
    }

    /**
     * Calculates change frequency
     * @param {moment} timestamp - Current time
     * @returns {string} Frequency description
     */
    calculateChangeFrequency(timestamp) {
        if (this.stateHistory.length < 2) return 'N/A';
        
        const timeDiff = moment.duration(
            timestamp.diff(this.stateHistory[0].timestamp)
        ).asMinutes();
        
        return `${(timeDiff / this.stateHistory.length).toFixed(1)} min/change`;
    }

    /**
     * Stores system state
     * @param {object} data - Current state data
     */
    storeState(data) {
        this.stateHistory.unshift({
            timestamp: moment().tz(config.TIMEZONE),
            data: JSON.parse(JSON.stringify(data))
        });

        if (this.stateHistory.length > this.MAX_HISTORY) {
            this.stateHistory.pop();
        }
    }

    /**
     * Initializes change detection
     * @returns {ChangeDetector} Instance for chaining
     */
    initialize() {
        this.metro.core.on('update', () => this.analyzeChanges());
        logger.info('CHANGE_DETECTOR_INIT', 'Initialized with MetroCore integration');
        return this;
    }
}

module.exports = ChangeDetector;
